#include <stdio.h>

int main()
{
    printf("Zdravo svete!");
    return 0;
}
