#include <stdio.h>
#define PI 3.14

int main()
{
	float r, P;
    printf("Unesite poluprecnik kruga\n");
    scanf("%f", &r);
    P = r * r * PI;
    printf("Povrsina kruga je %f", P);
    return 0;
}
