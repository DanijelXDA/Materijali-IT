#include <stdio.h>

int main()
{
    printf("Prolece\n");
    printf("Leto\n");
    printf("Jesen\n");
    printf("Zima");
    return 0;
}
