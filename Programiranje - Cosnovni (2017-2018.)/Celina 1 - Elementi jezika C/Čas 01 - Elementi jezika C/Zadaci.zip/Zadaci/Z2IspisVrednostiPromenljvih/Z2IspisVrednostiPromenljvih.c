#include <stdio.h>

int main()
{
    float god, godBrata;
	god = 18;
    printf("Ja imam %f godina", god);
    godBrata = god * 2;
    printf(", a moj brat dvostruko vise, %f godina.", godBrata);
    return 0;
}
