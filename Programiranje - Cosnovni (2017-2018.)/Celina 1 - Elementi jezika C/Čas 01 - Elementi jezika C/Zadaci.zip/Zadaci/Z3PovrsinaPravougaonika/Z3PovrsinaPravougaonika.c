#include <stdio.h>

int main()
{
    float a, b, P;
    printf("Unesite stranice pravougaonika:");
    scanf("%f %f", &a, &b);
    P = a * b;
    printf("Povrsina pravougaonika je %f", P);
    return 0;
}
