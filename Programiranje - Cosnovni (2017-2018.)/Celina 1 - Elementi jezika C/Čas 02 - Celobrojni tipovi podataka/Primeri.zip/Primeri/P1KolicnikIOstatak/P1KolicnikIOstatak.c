#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, kol, ost;

    printf("Unesite dva broja: ");
    scanf("%d %d", &a, &b);

    kol = a / b;
    ost = a % b;

    printf("Kolicnik unetih brojeva je %4d, a ostatak %3d.", kol, ost);
}
