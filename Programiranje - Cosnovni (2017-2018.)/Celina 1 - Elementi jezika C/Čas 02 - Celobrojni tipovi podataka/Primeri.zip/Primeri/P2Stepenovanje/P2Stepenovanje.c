#include <stdio.h>
#include <math.h>

int main()
{
    int a, b, stepen;

    printf("Unesite brojeve a i b: ");
    scanf("%d %d", &a, &b);

    a *= 2;
    b++;

    printf("Nove vrednosti brojeva su %d i %d,\n", a, b);

    stepen = pow(a, b);

    printf("a rezultat dobijen stepenovanjem: %d\n", stepen);
}
