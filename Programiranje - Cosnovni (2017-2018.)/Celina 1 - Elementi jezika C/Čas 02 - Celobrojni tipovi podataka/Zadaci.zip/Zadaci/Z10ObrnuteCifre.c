#include <stdio.h>
#include <stdlib.h>

int main()
{
    int broj,sto,deset,jedan,noviBroj;
    printf("Unesite trocifren broj:");
    scanf("%d",&broj);
    sto = broj / 100;
    deset = (broj / 10) % 10;
    jedan = broj % 10;
    noviBroj = 100 * jedan + 10 * deset + sto;
    printf("Broj dobijen od unetog obtanjem cifara je %d.",noviBroj);
}
