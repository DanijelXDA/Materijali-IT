#include <stdio.h>

int main() {
	int brojGodina = 15;
	printf("Ja imam %d godina.", brojGodina);
	return 0;
}	