#include <stdio.h>
#include <stdlib.h>

int main()
{
    int rezultat = (19 / 6) * 4 / 5 + 1;
    printf("Rezultat je %d",rezultat);
}
