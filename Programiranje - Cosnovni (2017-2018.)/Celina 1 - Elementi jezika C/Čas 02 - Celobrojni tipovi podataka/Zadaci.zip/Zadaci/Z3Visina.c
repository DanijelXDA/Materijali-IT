#include <stdio.h>

int main()
{
    unsigned visina; //moze i int
    printf("Unesite visinu(cm): ");
    scanf("%u", &visina); //ako int onda %i ili %d
    printf("Vasa visina je: %u cm", visina); //ako int onda %i ili %d
	return 0;
}
