#include <stdio.h>

int main()
{
    unsigned tezinaKg; //moze i int
    printf("Unesite tezinu(kg): ");
    scanf("%u", &tezinaKg); //ako int onda %i ili %d
    printf("Vasa tezina je: %u g", tezinaKg * 1000); //ako int onda %i ili %d
	return 0;
}
