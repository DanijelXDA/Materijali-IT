#include <stdio.h>
int main( ) {
	int celzijus, kelvin;
	printf("Unesite temperaturu u stepenima celzijusa: ");
	scanf("%d",&celzijus);
	kelvin = celzijus + 273;
	printf("%d stepeni celzijusa je %d stepeni kelvina\n", celzijus, kelvin);
	return 0;
}