#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int x, y, z, rezultat;

    printf("Unesite x: ");
    scanf("%d", &x);


    printf("Unesite y: ");
    scanf("%d", &y);


    printf("Unesite z: ");
    scanf("%d", &z);

    rezultat = x * x + y * (pow(z, 3) - pow(x, 4)) - (x * x - y * pow(z, 3));

    printf("Rezultat je %d", rezultat);
}
