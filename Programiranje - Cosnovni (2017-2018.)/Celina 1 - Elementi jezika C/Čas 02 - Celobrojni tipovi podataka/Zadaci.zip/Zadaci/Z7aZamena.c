#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b,pom;
    printf("Unesite dve vrednosti za zamenu:");
    scanf("%d %d",&a,&b);
    printf("Pre zamene vrednosti su a=%d, b=%d\n",a,b);
    pom = a;
    a = b;
    b = pom;
    printf("a posle zamene a=%d, b=%d.",a,b);
}
