#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    printf("Unesite dve vrednosti za zamenu:");
    scanf("%d %d",&a,&b);
    printf("Pre zamene vrednosti su a=%d, b=%d\n",a,b);
    b = a + b;
    a = b - a;
    b = b - a;
    printf("a posle zamene a=%d, b=%d.",a,b);
}
