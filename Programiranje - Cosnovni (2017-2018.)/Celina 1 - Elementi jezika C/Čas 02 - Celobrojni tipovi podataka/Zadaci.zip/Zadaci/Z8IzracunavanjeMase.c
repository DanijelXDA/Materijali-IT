#include <stdio.h>
#include <stdlib.h>

int main()
{
    int masa,kilogrami,grami;
    printf("Unesite masu u gramima:");
    scanf("%d",&masa);
    kilogrami = masa / 1000;
    grami = masa % 1000;
    printf("Uneta masa iznosi %d kilograma i %d grama",kilogrami,grami);
}
