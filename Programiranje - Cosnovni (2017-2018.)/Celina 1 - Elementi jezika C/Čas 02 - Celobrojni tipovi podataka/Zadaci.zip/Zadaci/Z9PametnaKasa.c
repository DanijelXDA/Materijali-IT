#include <stdio.h>

int main() {
	int kusur, krupne, srednje, kovanice;
	int brojKrupnih, brojSrednjih, brojKovanica;
	
	printf("Unesite kusur: ");
	scanf("%d", &kusur);
	printf("\nUnesite vrstu krupne novcanice[500, 200, 100]: ");
	scanf("%d", &krupne);
	printf("\nUnesite vrstu srednje novcanice[50, 20, 10]: ");
	scanf("%d", &srednje);
	printf("\nUnesite vrstu kovanice[5, 2, 1]: ");
	scanf("%d", &kovanice);
	
	brojKrupnih = kusur / krupne;
	brojSrednjih = (kusur % krupne) / srednje;
	brojKovanica = ((kusur % krupne) % srednje) / kovanice;
	
	printf("Vas kusur od %d dinara ce biti vracen u obliku:\n\t%d novcanica od %d dinara, \n\t%d novcanica od %d dinara, \n\t%d kovanica od %d dinara", brojKrupnih, krupne, brojSrednjih, srednje, brojKovanica, kovanice);
	return 0;
}