#include <stdio.h>
#include <float.h>

int main()
{
    printf("Velicine tipova u C-u:\n");
    printf("Velicina tipa int:%d\n", sizeof(int));
    printf("Velicina tipa short int: %d\n", sizeof(short int));
    printf("Velicina tipa long int: %d\n", sizeof(long int));
    printf("Velicina tipa float: %d\n", sizeof(float));
    printf("Velicina tipa double: %d\n", sizeof(double));
    printf("Velicina tipa long double: %d\n", sizeof(long double));
    printf("Maksimalna velicina podatka tipa float: %e; a preciznost: %d", FLT_MAX, FLT_DIG);
    printf("Maksimalna velicina podatka tipa double: %le; a preciznost: %d", DBL_MAX, DBL_DIG);

    return 0;
}
