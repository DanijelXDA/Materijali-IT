#include <stdio.h>
#include <stdlib.h>

int main()
{
    float a, b, kol;

    printf("Uneti brojeve a i b: ");
    scanf("%f %f", &a, &b);

    kol = a / b;

    printf("Kolicnik unetih brojeva je %5.2f", kol);

    return 0;
}
