#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    float d;

    printf("Unesite ceo broj:");
    scanf("%d", &i);
    printf("Unesite realan broj:");
    scanf("%f", &d);

    printf("Njihov zbir je %f\n", i + d);

    i = d;
    printf("Nakon dodele realnog celom broju dobijamo vrednost %d", i);

    return 0;
}
