#include <stdio.h>
#include <math.h>

int main()
{
    float x, y, rez;

    printf("Uneti vrednosti x i y: ");
    scanf("%f %f", &x, &y);

    rez = sqrt(fabs(1 - x)) - pow(2 - x, 2) / (pow(y, 2) + 1);
    printf("Vrednost izraza je %.3f", rez);

    return 0;
}
