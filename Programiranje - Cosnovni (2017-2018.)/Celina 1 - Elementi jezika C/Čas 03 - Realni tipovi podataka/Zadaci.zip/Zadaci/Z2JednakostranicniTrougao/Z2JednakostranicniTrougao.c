#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, O;
    float h, P;

    printf("Unesite duzinu stranice jednakostranicnog trougla: ");
    scanf("%i", &a);

    h = a * sqrt(3) / 2;
    printf("Visina trougla je: %.2f\n", h);

    O = 3 * a;
    printf("Obim trougla je: %i\n", O);

    P = a * h / 2;
    printf("Povrsina trougla je: %.2f\n", P);

    return 0;
}
