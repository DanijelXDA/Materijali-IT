#include <stdio.h>
#include <math.h>

int main()
{
    float a, b, c;

    printf("Uneti duzine kateta a i b: ");
    scanf("%f %f", &a, &b);

    c = sqrt(a * a + b * b);

    printf("Duzina hipotenuze je %f", c);

    return 0;
}
