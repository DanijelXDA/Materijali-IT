#include <stdio.h>
#include <stdlib.h>

int main()
{
    float t1, t2, t3;

    printf("Uneti vreme takmicara u 1. krugu: ");
    scanf("%f", &t1);
    printf("Uneti vreme takmicara u 2. krugu: ");
    scanf("%f", &t2);
    printf("Uneti vreme takmicara u 3. krugu: ");
    scanf("%f", &t3);

    printf("Prosecno vreme je %.3f", (t1 + t2 + t3) / 3);

    return 0;
}
