#include <stdio.h>
#include <stdlib.h>

int main()
{
    const float provizija = 0.015;
    float d, k, suma;

    printf("Uneti kolicinu dolara koje menjate: ");
    scanf("%f", &d);
    printf("Uneti kurs (koliko dinara vredi 1 dolar): ");
    scanf("%f", &k);

    suma = (d * k) * (1 - provizija);
    printf("Suma dinara koju dobijate je %f", suma);

    return 0;
}
