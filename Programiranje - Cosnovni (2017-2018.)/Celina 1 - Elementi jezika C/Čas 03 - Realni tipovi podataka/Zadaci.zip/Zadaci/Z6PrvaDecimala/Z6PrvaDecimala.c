#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x, decimalniDeo;
    int prvaDecimala;

    printf("Unesite realan broj: ");
    scanf("%f", &x);

    decimalniDeo = x - (int) x;
    prvaDecimala = (int) (decimalniDeo * 10);

    printf("Prva decimala u broju %.2f je: %i", x, prvaDecimala);

    return 0;
}
