#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;
    int i;

    printf("Unesite neki znak: ");
    scanf("%c", &c);

    printf("Njegov ASCII kod je %d\n", c);

    i = c;
    printf("Njegov ASCII kod je %d", i);

    return 0;
}
