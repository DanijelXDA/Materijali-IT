#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;
    int i;

    printf("Unesite cifru koja treba da se pretvori iz znaka u ceo broj: ");
    scanf("%c", &c);

    i = c - '0';
    printf("Uneta cifra je %d", i);

    return 0;
}
