#include <stdio.h>
#include <stdlib.h>

int main()
{
    char veliko = 'A', malo = 'z', velikoUMalo, maloUVeliko;

    velikoUMalo = tolower(veliko);
    maloUVeliko = toupper(malo);

    printf("Karakter %c nakon uvecanja: %c\n", malo, maloUVeliko);
    printf("Karakter %c nakon umanjenja: %c\n", veliko, velikoUMalo);

    return 0;
}
