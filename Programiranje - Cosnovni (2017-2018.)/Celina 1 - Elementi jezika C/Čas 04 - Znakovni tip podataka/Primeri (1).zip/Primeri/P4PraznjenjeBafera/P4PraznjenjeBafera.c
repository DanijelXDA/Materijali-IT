#include <stdio.h>
#include <stdlib.h>

int main()
{
    char iIme, iPrezime;

    printf("Unesite inicijal vaseg imena: ");
    scanf("%c", &iIme);

    printf("Unesite inicijal vaseg prezimena: ");
    fflush(stdin); //zakomentarisati ovu naredbu i videti kako se program ponasa
    scanf("%c", &iPrezime);

    printf("Vasi inicijali su %c%c", iIme, iPrezime);

    return 0;
}
