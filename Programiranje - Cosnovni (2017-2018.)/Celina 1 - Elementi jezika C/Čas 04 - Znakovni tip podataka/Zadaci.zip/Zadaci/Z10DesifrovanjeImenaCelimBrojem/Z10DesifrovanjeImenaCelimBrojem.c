#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sifra;
    char z1, z2, z3;

    printf("Unesite vasu sifru: ");
    scanf("%i", &sifra);

    z3 = sifra % 1000;
    sifra /= 1000;

    z2 = sifra % 1000;
    sifra /= 1000;

    z1 = sifra % 1000;

    printf("Desifrovano ime: %c%c%c", z1, z2, z3);

    return 0;
}
