#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    char c;

    printf("Unesite ASCII kod nekog znaka: ");
    scanf("%i", &i);

    printf("Taj znak je %c\n", i);

    c = i;
    printf("Taj znak je %c", c);

    return 0;
}
