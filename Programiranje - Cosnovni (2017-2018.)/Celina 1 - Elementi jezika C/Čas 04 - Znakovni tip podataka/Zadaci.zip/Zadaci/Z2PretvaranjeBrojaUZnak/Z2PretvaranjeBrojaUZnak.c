#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;
    char c;

    printf("Unesite cifru koja treba da se pretvori iz broja u znak: ");
    scanf("%i", &i);

    c = '0' + i;
    printf("Uneta cifra je %c", c);

    return 0;
}
