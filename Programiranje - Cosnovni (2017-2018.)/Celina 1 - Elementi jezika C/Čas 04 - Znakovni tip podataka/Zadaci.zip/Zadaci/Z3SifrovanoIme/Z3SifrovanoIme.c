#include <stdio.h>
#include <stdlib.h>

int main()
{
    char s1, s2, s3, s4, s5;

    printf("Uneti ime od 5 slova: ");
    scanf("%c%c%c%c%c", &s1, &s2, &s3, &s4, &s5);

    printf("Sifrovano ime: %i %i %i %i %i", s1, s2, s3, s4, s5);

    return 0;
}
