#include <stdio.h>
#include <stdlib.h>

int main()
{
    int s1, s2, s3, s4, s5;

    printf("Uneti sifru imena od 5 slova: ");
    scanf("%i %i %i %i %i", &s1, &s2, &s3, &s4, &s5);

    printf("Desifrovano ime: %c%c%c%c%c", s1, s2, s3, s4, s5);

    return 0;
}
