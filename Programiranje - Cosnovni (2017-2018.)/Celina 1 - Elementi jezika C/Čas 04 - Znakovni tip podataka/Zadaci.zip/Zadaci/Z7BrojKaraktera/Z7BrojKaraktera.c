#include <stdio.h>
#include <stdlib.h>

int main()
{
    char znak1, znak2;
    int brojZnakovaIzmedju;

    printf("Unesite dva znaka: ");
    scanf("%c %c", &znak1, &znak2);

    brojZnakovaIzmedju = znak2 - znak1 - 1;
    printf("Izmedju znakova '%c' i '%c' postoji %i znakova", znak1, znak2, brojZnakovaIzmedju);

    return 0;
}
