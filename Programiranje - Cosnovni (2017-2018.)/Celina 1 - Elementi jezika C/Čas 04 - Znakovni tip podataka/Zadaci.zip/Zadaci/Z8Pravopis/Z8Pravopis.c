#include <stdio.h>
#include <stdlib.h>

int main()
{
    char z1, z2, z3, z4, z5, s1, s2, s3, s4, s5;

    printf("Unesite ime koje ima tacno 5 slova: ");
    scanf("%c %c %c %c %c", &z1, &z2, &z3, &z4, &z5);

    s1 = toupper(z1);
    s2 = tolower(z2);
    s3 = tolower(z3);
    s4 = tolower(z4);
    s5 = tolower(z5);
    printf("Sredjeno ime: %c%c%c%c%c", s1, s2, s3, s4, s5);

    return 0;
}
