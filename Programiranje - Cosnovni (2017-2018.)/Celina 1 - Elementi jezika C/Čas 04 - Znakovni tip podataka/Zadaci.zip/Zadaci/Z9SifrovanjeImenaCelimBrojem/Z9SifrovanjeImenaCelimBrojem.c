#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sifra;
    char z1, z2, z3;

    printf("Unesite ime koje ima tacno 3 karaktera.\n");

    printf("Unesite 1. karakter: \n");
    scanf("%c", &z1);

    printf("Unesite 2. karakter: \n");
    fflush(stdin);
    scanf("%c", &z2);

    printf("Unesite 3. karakter: \n");
    fflush(stdin);
    scanf("%c", &z3);

    sifra = z1 * 1000000 + z2 * 1000 + z3;
    printf("Sifrovano ime: %i", sifra);

    return 0;
}
