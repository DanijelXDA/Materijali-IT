#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;

    printf("Uneti ceo broj: ");
    scanf("%d", &n);

    if(n > 3)
        printf("Uneti broj je veci od 3.");

    return 0;
}
