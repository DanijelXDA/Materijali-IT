#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    printf("Uneti ceo broj: ");
    scanf("%d", &n);

    if(n % 2 == 0)
        printf("Uneti broj je paran.");
    else
        printf("Uneti broj je neparan.");

    return 0;
}
