#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, polaN;

    printf("Uneti ceo broj: ");
    scanf("%d", &n);

    if(n % 2 == 0 && n > 0)
    {
        polaN = n / 2;
        printf("Uneti broj je paran, a njegova polovina je %d.", polaN);
    }

    return 0;
}
