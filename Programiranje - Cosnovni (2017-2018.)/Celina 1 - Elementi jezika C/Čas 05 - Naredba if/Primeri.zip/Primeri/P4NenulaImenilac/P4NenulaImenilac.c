#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x, y, rez;

    printf("Unesite brojeve x i y: ");
    scanf("%f %f", &x, &y);

    if(x - y == 0)
        printf("Deljenje nulom nije dozvoljeno.");
    else
    {
        rez = (x + y) / (x - y);
        printf("Rezultat je %f", rez);
    }

    return 0;
}
