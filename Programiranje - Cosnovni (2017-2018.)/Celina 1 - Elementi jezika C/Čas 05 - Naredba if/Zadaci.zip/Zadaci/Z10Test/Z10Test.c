#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int procenat = 20;
    int brZadataka, brBodovaPoZadatku, ucenikBodovi, max;
    float prolaz;

    printf("Unesite broj zadataka na testu: ");
    scanf("%d", &brZadataka);

    printf("Unesite broj bodova koliko svaki zadatak nosi: ");
    scanf("%d", &brBodovaPoZadatku);

    printf("Unesite broj bodova koje je ucenik osvojio: ");
    scanf("%d", &ucenikBodovi);

    max = brZadataka * brBodovaPoZadatku;
    prolaz = max * procenat / 100.0; //obavezno 100.0 (ili neki od drugih metoda) da ne bi bilo celobrojno deljenje!

    printf("Maksimalan broj bodova: %d, bodovi potrebni za prolaz: %f, ucenik ", max, prolaz);
    if(ucenikBodovi >= prolaz)
        printf("je");
    else
        printf("nije");
    printf(" prosao test.\n");

    return 0;
}
