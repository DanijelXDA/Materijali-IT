#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;

    printf("Unesite ceo broj: ");
    scanf("%d", &x);

    if(x % 3 == 0)
        printf("Uneseni broj je deljiv sa 3.\n");
    else
        printf("Uneseni broj nije deljiv sa 3.\n");

    return 0;
}
