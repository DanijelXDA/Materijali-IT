#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Unesite dva cela broja: ");
    scanf("%d %d", &a, &b);

    if(a >= b)
        printf("Maksimum unetih brojeva je %d.\n", a);
    else
        printf("Maksimum unetih brojeva je %d.\n", b);

    return 0;
}
