#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;

    printf("Unesite ceo broj: ");
    scanf("%d", &x);

    if(1 < x && x < 100 && !(10 < x && x < 20))
        printf("Uneseni broj je u zadatom skupu.\n");
    else
        printf("Uneseni broj nije u zadatom skupu.\n");

    return 0;
}
