#include <stdio.h>
#include <stdlib.h>

int main()
{
    char karakter;

    printf("Unesite karakter: ");
    scanf("%c", &karakter);

    printf("Uneti karakter %c ", karakter);
    if(karakter - '0' >= 0 && karakter - '0' <= 9)
    {
        printf("je cifra.");
    }
    else
    {
        printf("nije cifra.");
    }

    return 0;
}

