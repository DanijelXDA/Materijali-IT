#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float a, P;

    printf("Unesite povrsinu kvadrata: ");
    scanf("%f", &P);

    if(P >= 0)
    {
        a = sqrt(P);
        printf("Stranica tog kvadrata je %f.\n", a);
    }
    else
        printf("Povrsina ne moze biti negativna!\n");

    return 0;
}
