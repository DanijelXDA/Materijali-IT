#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int TEKUCA_GODINA = 2018;
    int godinaRodjenja;

    printf("Unesite godinu rodjenja: ");
    scanf("%d", &godinaRodjenja);

    printf("\nOsoba rodjena %d. godine ", godinaRodjenja);
    if(TEKUCA_GODINA - godinaRodjenja >= 18)
        printf("jeste punoletna.\n");
    else
        printf("nije punoletna.\n");

    return 0;
}
