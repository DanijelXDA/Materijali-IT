#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;

    printf("Unesite neki znak: ");
    scanf("%c", &c);

    if('a' <= c && c <= 'z' || 'A' <= c && c <= 'Z')
        printf("Uneseni znak jeste slovo.\n");
    else
        printf("Uneseni znak nije slovo.\n");

    return 0;
}
