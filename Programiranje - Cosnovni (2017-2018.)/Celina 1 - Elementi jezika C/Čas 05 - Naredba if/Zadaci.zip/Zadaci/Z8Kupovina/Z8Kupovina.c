#include <stdio.h>
#include <stdlib.h>

int main() {
    const float DONJA_GRANICA = 1000.0;
    const float GORNJA_GRANICA = 2500.0;
    float cena;

    printf("Unesite cenu proizvoda: ");
    scanf("%f", &cena);

    printf("Proizvod koji kosta %f dinara ", cena);
    if(cena >= DONJA_GRANICA && cena <= GORNJA_GRANICA)
        printf("je kupljen.\n");
    else
        printf("nije kupljen.\n");

    return 0;
}
