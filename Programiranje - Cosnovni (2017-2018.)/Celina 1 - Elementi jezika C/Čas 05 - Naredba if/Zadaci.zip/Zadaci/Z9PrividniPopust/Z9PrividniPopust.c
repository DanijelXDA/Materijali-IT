#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float stara_cena, nova_cena;
    int popust;

    printf("Unesite staru cenu (u dinarima): ");
    scanf("%f", &stara_cena);

    if(stara_cena < 0)
        printf("GRESKA: Uneli ste nedozvoljenu cenu (negativan broj)!\n");
    else
    {
        printf("Unesite popust: ");
        scanf("%d", &popust);

        popust = abs(popust);
        nova_cena = stara_cena / (1 - (float)popust / 100);  //obavezno (float)popust (ili neki od drugih metoda) da ne bi bilo celobrojno deljenje!

        printf("Nova cena iznosi: %.2f dinara\n", nova_cena);
    }

    return 0;
}
