#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x, y, max;

    printf("Uneti dva broja: ");
    scanf("%f %f", &x, &y);

    max = x > y ? x : y;

    printf("max(x, y) = %f", max);

    return 0;
}
