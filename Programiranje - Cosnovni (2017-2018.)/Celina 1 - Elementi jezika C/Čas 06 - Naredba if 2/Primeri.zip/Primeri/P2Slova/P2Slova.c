#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;

    printf("Uneti znak: ");
    scanf("%c", &c);

    if('a' <= c && c <= 'z' || 'A' <= c && c <= 'Z')
    {
        printf("Uneti znak je slovo, i to ");
        if('a' <= c && c <= 'z')
            printf("malo slovo.");
        else
            printf("veliko slovo.");
    }
    else
        printf("Uneti znak nije slovo.");

    return 0;
}
