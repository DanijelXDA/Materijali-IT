#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x;
    int sg;

    printf("Unesite x: ");
    scanf("%f", &x);

    if(x > 0)
        sg = 1;
    else if(x == 0)
        sg = 0;
    else
        sg = -1;

    printf("sg(x) = %d", sg);

    return 0;
}
