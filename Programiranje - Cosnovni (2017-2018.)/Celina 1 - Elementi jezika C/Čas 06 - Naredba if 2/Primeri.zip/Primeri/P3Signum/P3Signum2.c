#include <stdio.h>
#include <stdlib.h>

int main()
{
    float x;
    int sg;

    printf("Unesite x: ");
    scanf("%f", &x);

	sg = (x > 0) ? 1 : ((x == 0) ? 0 : -1); //moze i bez zagrada ali je onda teze uociti delove ternarnih operatora

    printf("sg(x) = %d", sg);

    return 0;
}
