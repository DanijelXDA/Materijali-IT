#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, max;
	
    printf("Uneti tri broja: ");
    scanf("%d %d %d", &a, &b, &c);
    
	if(a >= b && a >= c)
        max = a;
    else if(b >= a && b >= c)
        max = b;
    else
        max = c;
	
    printf("Maksimum unetih brojeva je %d", max);
    
	return 0;
}
