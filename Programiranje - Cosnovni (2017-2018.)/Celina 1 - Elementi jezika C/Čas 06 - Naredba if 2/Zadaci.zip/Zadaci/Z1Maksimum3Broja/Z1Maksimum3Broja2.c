#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, max;
	
    printf("Uneti tri broja: ");
    scanf("%d %d %d", &a, &b, &c);
    
	if(a >= b)
    {
        if (a >= c)
            max = a;
        else
            max = c;
    }
    else
    {
        if(b >= c)
            max = b;
        else
            max = c;
    }

    printf("Maksimum unetih brojeva je %d", max);

    return 0;
}
