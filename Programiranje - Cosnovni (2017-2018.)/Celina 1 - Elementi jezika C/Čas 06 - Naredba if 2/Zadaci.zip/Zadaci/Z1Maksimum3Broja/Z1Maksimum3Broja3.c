#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, max;
	
    printf("Uneti tri broja: ");
    scanf("%d %d %d", &a, &b, &c);
    
	max = a;
    if(b > max)
        max = b;
    if(c > max)
        max = c;
	
    printf("Maksimum unetih brojeva je %d", max);
    
	return 0;
}
