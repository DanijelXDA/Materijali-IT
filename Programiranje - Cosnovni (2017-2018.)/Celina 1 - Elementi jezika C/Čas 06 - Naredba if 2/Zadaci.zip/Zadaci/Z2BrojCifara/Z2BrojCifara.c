#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
	
    printf("Uneti prirodan broj: ");
    scanf("%d", &n);
    
	if(n <= 9)
        printf("Uneti broj ima 1 cifru.");
    else if(n >= 10 && n <= 99)
        printf("Uneti broj ima 2 cifre.");
    else if(n >= 100 && n <= 999)
        printf("Uneti broj ima 3 cifre.");
    else
        printf("Uneti broj ima vise od 3 cifre.");
    
	return 0;
}
