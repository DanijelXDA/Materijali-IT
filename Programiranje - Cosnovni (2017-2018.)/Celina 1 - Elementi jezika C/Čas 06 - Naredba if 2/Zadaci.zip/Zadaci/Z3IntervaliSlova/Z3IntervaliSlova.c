#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;
    
	printf("Uneti znak: ");
    scanf("%c", &c);
    
	if('a' <= c && c <= 'k')
        printf("Uneto slovo je u intervalu izmedju a i k.");
    else if('l' <= c && c <= 'z')
        printf("Uneto slovo je u intervalu izmedju l i z.");
    else
        printf("Nije uneto malo slovo.");
    
	return 0;
}
