#include <stdio.h>
#include <stdlib.h>

int main()
{
    int god;

    printf("Uneti godinu: ");
    scanf("%d", &god);

    if((god % 400 == 0) || (god % 4 == 0 && god % 100 != 0))
        printf("Uneta godina je prestupna.");
    else
        printf("Uneta godina nije prestupna.");
    
	return 0;
}
