#include <stdio.h>
#include <stdlib.h>

int main()
{
    int oMat, oSJ, oFV, oInf;
	float prosek;

    printf("Unesite ocenu iz predmeta Matematika: ");
    scanf("%d", &oMat);
	
	printf("Unesite ocenu iz predmeta Srpski jezik: ");
    scanf("%d", &oSJ);
	
	printf("Unesite ocenu iz predmeta Fizicko vaspitanje: ");
    scanf("%d", &oFV);
	
	printf("Unesite ocenu iz predmeta Informatika: ");
    scanf("%d", &oInf);
	
	if(oMat == 1 || oSJ == 1 || oFV == 1 || oInf == 1)
	{
		prosek = 1;
	}
	else 
	{
		prosek = (oMat + oSJ + oFV + oInf) / 4.0;
	}
    
	printf("Vas prosek je %.2f", prosek);
    
	return 0;
}
