#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, d, brPoz = 0;
	
    printf("Uneti cetiri broja: ");
    scanf("%d %d %d %d", &a, &b, &c, &d);
    
	if(a > 0)
        brPoz++;
    if(b > 0)
        brPoz++;
    if(c > 0)
        brPoz++;
    if(d > 0)
        brPoz++;
	
    printf("Medju unetim brojevima je %d pozitivnih", brPoz);
    
	return 0;
}
