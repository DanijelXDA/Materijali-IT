#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned dan;
	float iznos;

    printf("Unesite iznos racuna koji placate: ");
    scanf("%f", &iznos);

	printf("Unesite dan placanja: ");
    scanf("%u", &dan);

	if(dan > 20)
	{
		printf("Prosao je 20 dan u mesecu, morate da platite %.2f dinara.", iznos * 1.1); //1.1 predstavlja 110%
	}
	else if(iznos >= 1000)
	{
		printf("Racun uspesno placen. Dobili ste status ZLATNOG POTROSACA.");
	}
	else
	{
		printf("Racun uspesno placen.");
    }

	return 0;
}
