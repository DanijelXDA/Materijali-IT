#include <stdio.h>
#include <math.h>

int main()
{
    const float PI = 3.14;
    float a, b, c, r, s, O, P;
    char izbor1, izbor2;
    
	printf("Izabrati figuru (k - krug, p - pravougaonik, t- trougao): ");
    scanf("%c", &izbor1);
    
	printf("Izabrati sta se racuna (o - obim, p - povrsina): ");
	fflush(stdin);
    scanf("%c", &izbor2);
    
	if(izbor1 == 'k')
    {
        printf("Uneti poluprecnik kruga: ");
        scanf("%f", &r);
        
		if(izbor2 == 'o')
            printf("Obim kruga je %f", 2 * r * PI);
        else if(izbor2 == 'p')
            printf("Povrsina kruga je %f", r * r * PI);
    }
    else if(izbor1 == 'p')
    {
        printf("Uneti stranice pravougaonika: ");
        scanf("%f %f", &a, &b);
        
		if(izbor2 == 'o')
            printf("Obim pravougaonika je %f", 2 * (a + b));
        else if(izbor2 == 'p')
            printf("Povrsina pravougaonika je %f", a * b);
    }
    else if(izbor1 == 't')
    {
        printf("Uneti stranice trougla: ");
        scanf("%f %f %f", &a, &b, &c);
        
		if(izbor2 == 'o')
            printf("Obim trougla je %f", a + b + c);
        else if(izbor2 == 'p')
        {
            s = (a + b + c) / 2;
            printf("Povrsina trougla je %f", sqrt(s * (s - a) * (s - b) * (s - c)));
        }
    }
	
    return 0;
}
