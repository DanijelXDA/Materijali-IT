#include <stdio.h>
#include <math.h>

int main()
{
    char izborDaNe;
	int izborBroj, brTacnih = 0, bodoviZadatka = 25;

	printf("Zelite li da se igrate (D/d za DA, N/n za NE): ");
    scanf("%c", &izborDaNe);

	if(izborDaNe == 'D' || izborDaNe == 'd')
	{
		printf("1. Koliko bajtova zauzima podatak tipa int (najcesce)? ");
		scanf("%d", &izborBroj);

		if(izborBroj == 4)
			brTacnih++;

        printf("Zelite li da nastavite da se igrate (D/d za DA, N/n za NE): ");
        fflush(stdin);
        scanf("%c", &izborDaNe);

        if(izborDaNe == 'D' || izborDaNe == 'd')
        {
            printf("2. Koja je najveca cifra koju moze da ima broj zapisan u oktalnom sistemu? ");
            scanf("%d", &izborBroj);

            if(izborBroj == 7)
                brTacnih++;

            printf("Zelite li da nastavite da se igrate (D/d za DA, N/n za NE): ");
            fflush(stdin);
            scanf("%c", &izborDaNe);

            if(izborDaNe == 'D' || izborDaNe == 'd')
            {
                printf("3. Koliko vrednosti moze da ima promenjiva bool tipa? ");
                scanf("%d", &izborBroj);

                if(izborBroj == 2)
                    brTacnih++;

                printf("Zelite li da nastavite da se igrate (D/d za DA, N/n za NE): ");
                fflush(stdin);
                scanf("%c", &izborDaNe);

                if(izborDaNe == 'D' || izborDaNe == 'd')
                {
                    printf("4. Da li je napisani uslov dobar ukoliko zelimo da daje tacno za bilo koji dvocifreni broj x (D/d za DA, N/n za NE)? USLOV: (x > 10 && x < 1000) ");
                    fflush(stdin);
                    scanf("%c", &izborDaNe);

                    if(izborDaNe == 'N' || izborDaNe == 'n')
                        brTacnih++;
                }
            }
        }
    }

	printf("Kraj kviza. Osvojili ste %d bodova.", brTacnih * bodoviZadatka);

    return 0;
}
