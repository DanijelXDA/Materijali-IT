#include <stdio.h>
#include <stdlib.h>

int main()
{
    char boja;
    printf("Unesite boju na semaforu (z-zelena, u-zuta, c-crvena): ");
    boja = getchar();
    boja = tolower(boja);
    if (boja=='z')
        printf("Zelena: kreni");
    else if (boja=='u')
        printf("Zuta: pripremi se");
    else if (boja=='c')
        printf("Crvena: stani");
    else
        printf("Ova boja nije definisana");
    return 0;
}
