#include <stdio.h>
#include <stdlib.h>

// Za uneti broj n (n<=5) ispisuje zbir brojeva od 1 do n

int main()
{
    int n, zbir;
    printf("Unesite broj n (1<=n<=5)do kojeg zelite zbir: ");
    scanf("%d", &n);
    if (n<1 || n>5)
        printf("Pogresan unos!");
    else
    {
        zbir = 0;
        switch(n) {
        case 5:
            zbir = zbir + 5;
        case 4:
            zbir = zbir + 4;
        case 3:
            zbir = zbir + 3;
        case 2:
            zbir = zbir + 2;
        case 1:
            zbir = zbir + 1;
        }
        printf("Zbir brojeva od 1 do %d je %d", n, zbir);
    }
    return 0;
}
