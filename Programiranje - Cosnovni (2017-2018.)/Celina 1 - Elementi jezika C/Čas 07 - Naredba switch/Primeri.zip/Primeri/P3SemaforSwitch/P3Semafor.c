#include <stdio.h>
#include <stdlib.h>

int main()
{
    char boja;
    printf("Unesite boju na semaforu (z-zelena, u-zuta, c-crvena): ");
    boja = getchar();
    switch(tolower(boja))
    {
        case 'z':
            printf("Zelena: kreni");
            break;
        case 'u':
            printf("Zuta: pripremi se");
            break;
        case 'c':
            printf("Crvena: stani");
            break;
        default:
            printf("Ova boja nije definisana");
    }
    return 0;
}
