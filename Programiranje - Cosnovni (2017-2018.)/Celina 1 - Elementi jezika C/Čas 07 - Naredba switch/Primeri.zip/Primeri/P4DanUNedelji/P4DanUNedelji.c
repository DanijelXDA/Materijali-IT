#include <stdio.h>
#include <stdlib.h>

int main()
{
  int prvi,danas;
  printf("Unesite datum prvog ponedeljka u mesecu: ");
  scanf("%d",&prvi);
  printf("Unesite redni broj u mesecu danasnjeg dana: ");
  scanf("%d",&danas);
  switch((danas - prvi + 7) % 7)                //dodajemo 7 jer razlika moze biti negativna
  {
     	case 0: printf("Danas je ponedeljak.");
                break;
        case 1: printf("Danas je utorak.");
                break;
        case 2: printf("Danas je sreda.");
                break;
        case 3: printf("Danas je cetvrtak.");
                break;
        case 4: printf("Danas je petak.");
                break;
        case 5: printf("Danas je subota.");
                break;
        case 6: printf("Danas je nedelja.");
                break;
  }
  return 0;
}
