#include <stdio.h>
#include <stdlib.h>
// Za uneti redni dan u nedelji, naisati da li je
// taj dan radni dan ili vikend

int main()
{
    int dan;
    printf("Unesite redni broj dana u nedelji:");
    scanf("%d", &dan);
    switch(dan) {
     case 1:
     case 2:
     case 3:
     case 4:
     case 5:
         printf("Radni dan :(");
         break;
     case 6: case 7:
         printf("Vikend :)");
         break;
     default:
         printf("Nema tog dana u nedelji!");
    }
    return 0;
}
