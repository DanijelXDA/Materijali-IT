#include <stdio.h>
#include <stdlib.h>

int main()
{
  char znak;
  printf("Unesite neki znak:");
  scanf("%c",&znak);
  switch(znak)
	{
     	case ' ':
     	    printf("Unet je razmak.");
     	    break;
        case '0': case '1': case '2': case '3': case '4':
        case '5': case '6': case '7': case '8': case '9':
             printf("Uneta je cifra.");
             break;
        case '.': case ',': case ';':
            printf("Unet je znak interpunkcije.");
            break;
        default:
            printf("Unet je neki od ostalih znakova.");
	}
    return 0;
}
