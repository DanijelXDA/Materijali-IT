#include <stdio.h>
#include <stdlib.h>

int main()
{
  double a,b,rez;
  char operacija;
  printf("Unesite dva broja:");
  scanf("%lf %lf",&a,&b);
  printf("Unesite operaciju (+,-,*,/):");
  scanf(" %c",&operacija);
  if(operacija == '+')
    rez = a + b;
  else if(operacija == '-')
    rez = a - b;
  else if(operacija == '*')
    rez = a * b;
  else if(operacija == '/')
    rez = a / b;
  printf("Rezultat je %lf",rez);
  return 0;
}
