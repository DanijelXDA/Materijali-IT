#include <stdio.h>
#include <stdlib.h>

int main()
{
    int d,m,brDana;
    printf("Uneti dan i mesec:");
    scanf("%d %d",&d,&m);
    brDana = d;
    switch(m)
    {
        case 12: brDana += 30;
        case 11: brDana += 31;
        case 10: brDana += 30;
        case 9: brDana += 31;
        case 8: brDana += 31;
        case 7: brDana += 30;
        case 6: brDana += 31;
        case 5: brDana += 30;
        case 4: brDana += 31;
        case 3: brDana += 28;
        case 2: brDana += 31;
    }
    printf("%d. %d. je %d. dan u godini.",d,m,brDana);
    return 0;
}
