#include <stdio.h>
#include <stdlib.h>

int main()
{
  char prvoSlovo;
  printf("Unesite prvo slovo zivotinje (z/l/v): ");
  scanf("%c",&prvoSlovo);
  switch (prvoSlovo) {
    case 'z':
       printf("Zivotinja je zec");
       break;
    case 'l':
       printf("Zivotinja je lav");
       break;
    case 'v':
       printf("Zivotinja je vuk");
       break;
    default:
       printf("Ne postoji takva zivotinja");
  }


  return 0;
}
