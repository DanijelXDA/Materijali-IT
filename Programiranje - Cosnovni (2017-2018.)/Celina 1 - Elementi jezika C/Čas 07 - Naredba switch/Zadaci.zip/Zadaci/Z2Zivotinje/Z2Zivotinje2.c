#include <stdio.h>
#include <stdlib.h>

int main()
{
  char prvoSlovo, drugoSlovo;
  printf("Unesite prvo slovo zivotinje (z/l/v): ");
  scanf("%c",&prvoSlovo);
  switch (prvoSlovo) {
    case 'z':
       printf("Zivotinja je zec");
       break;
    case 'l':
       printf("Unesite drugo slovo zivotinje (z/l/v): ");
       scanf(" %c",&drugoSlovo);
       switch(drugoSlovo){
          case 'a':
            printf("Zivotinja je lav");
            break;
          case 'i':
            printf("Zivotinja je lisica");
            break;
          default:
            printf("Ne postoji takva zivotinja");
       }
       break;
    case 'v':
       printf("Zivotinja je vuk");
       break;
    default:
       printf("Ne postoji takva zivotinja");
  }


  return 0;
}
