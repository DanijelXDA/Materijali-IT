#include <stdio.h>
#include <stdlib.h>

int main()
{
  int n;
  double a,b,r,O;
  const double pi = 3.14;
  printf("Izaberite figuru: (1) Kvadrat; (2) Pravougaonik; (3) Krug: ");
  scanf("%d",&n);
  switch(n)
  {
     	case 1: printf("Unesite stranicu kvadrata:");
                scanf("%lf",&a);
                O = 4 * a;
                break;
        case 2: printf("Unesite stranice pravougaonika:");
                scanf("%lf %lf",&a,&b);
                O = 2 * (a + b);
                break;
        case 3: printf("Unesite poluprecnik kruga:");
                scanf("%lf",&r);
                O = 2 * r * pi;
                break;
  }
  printf("Obim figure je %lf",O);
  return 0;
}
