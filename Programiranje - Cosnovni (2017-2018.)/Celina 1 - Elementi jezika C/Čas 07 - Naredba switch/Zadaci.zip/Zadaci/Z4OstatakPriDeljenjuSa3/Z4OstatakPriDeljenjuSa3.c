#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    printf("Unesite broj x:\n");
    scanf("%d", &x);
    switch(x%3) {
      case 0:
          printf("Ostatak je nula!");
          break;
      case 1:
          printf("Ostatak je jedan!");
          break;
      case 2:
          printf("Ostatak je dva!");
          break;
    }
}
