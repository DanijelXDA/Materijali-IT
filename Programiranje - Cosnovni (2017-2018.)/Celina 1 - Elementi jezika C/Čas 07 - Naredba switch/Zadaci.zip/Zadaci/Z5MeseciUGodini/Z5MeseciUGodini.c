#include <stdio.h>
#include <stdlib.h>

int main()
{
    int brDana;
    printf("Uneti broj dana u mesecu:");
    scanf("%d",&brDana);
    switch(brDana)
    {
        case 31:
            printf("Toliko dana imaju: januar, mart, maj, jul, avgust, oktobar i decembar.");
            break;
        case 30:
            printf("Toliko dana imaju: april, jun, septembar i novembar.");
            break;
        case 28:
        case 29:
            printf("Toliko dana ima februar.");
            break;
        default:
            printf("Ne postoji mesec sa %d dana.",brDana);
            break;
    }
    return 0;
}
