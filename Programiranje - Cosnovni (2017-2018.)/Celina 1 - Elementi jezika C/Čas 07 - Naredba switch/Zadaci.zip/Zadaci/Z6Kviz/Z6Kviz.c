#include <stdio.h>
#include <stdlib.h>

int main()
{
    int odgovor;
    printf("Koliko ima ukupno naredbi i operatora grananja, 1, 2, 3 ili 4?");
    scanf("%d", &odgovor);
    switch (odgovor){
      case 1:
      case 2:
      case 4:
        printf("Netacan odgovor!");
        break;
      case 3:
        printf("Tacan odgovor!");
        break;
      default:
        printf("Nepostojeci odgovor!");
    }
    return 0;
}
