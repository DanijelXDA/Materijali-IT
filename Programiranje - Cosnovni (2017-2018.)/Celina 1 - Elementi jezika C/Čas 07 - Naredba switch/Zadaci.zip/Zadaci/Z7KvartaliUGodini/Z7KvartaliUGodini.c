#include <stdio.h>
#include <stdlib.h>

int main()
{
    int mesec;
    printf("Unesite redni broj meseca: \n");
    scanf("%d", &mesec);
    // resenje preko switch-a
    switch(mesec){
        case 1: case 2: case 3:
            printf("Prvi kvartal.");
            break;
        case 4: case 5: case 6:
            printf("Drugi kvartal.");
            break;
        case 7: case 8: case 9:
            printf("Treci kvartal.");
            break;
        case 10: case 11: case 12:
            printf("Cetvrti kvartal.");
            break;
        default:
            printf("Nepostojeci kvartal!!!");
    }
    return 0;
}
