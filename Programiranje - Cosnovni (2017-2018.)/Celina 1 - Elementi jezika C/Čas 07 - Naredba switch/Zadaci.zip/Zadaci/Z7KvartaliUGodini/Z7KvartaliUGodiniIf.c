#include <stdio.h>
#include <stdlib.h>

int main()
{
    int mesec;
    printf("Unesite redni broj meseca: \n");
    scanf("%d", &mesec);
    // resenje preko if-a
    if (1<=mesec && mesec <=3)
        printf("Prvi kvartal.\n");
    else if (4<=mesec && mesec <=6)
        printf("Drugi kvartal.\n");
    else if (7<=mesec && mesec <=9)
        printf("Treci kvartal.\n");
    else if (10<=mesec && mesec <=12)
        printf("Cetvrti kvartal.\n");
    else
        printf("Nepostojeci kvartal!!!\n");
    return 0;
}
