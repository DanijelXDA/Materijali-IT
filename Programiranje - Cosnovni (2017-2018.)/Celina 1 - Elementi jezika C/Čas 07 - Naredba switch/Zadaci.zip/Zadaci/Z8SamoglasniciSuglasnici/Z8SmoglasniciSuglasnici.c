#include <stdio.h>
#include <stdlib.h>

int main()
{
    char slovo, maloslovo;
    printf("Unesite jedno slovo: ");
    scanf("%c", &slovo);
    maloslovo = tolower(slovo);
    // resenje preko switch
    switch(maloslovo)
    {
    case 'a':
    case 'e':
    case 'i':
    case 'o':
    case 'u':
        printf("Slovo %c je samoglasnik", slovo);
        break;
    default:
        printf("Slovo %c je suglasnik", slovo);
    }
    return 0;
}
