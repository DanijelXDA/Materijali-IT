#include <stdio.h>
#include <stdlib.h>

int main()
{
    char slovo, maloslovo;
    printf("Unesite jedno slovo: ");
    scanf("%c", &slovo);
    maloslovo = tolower(slovo);
    // resenje preko if
    if (slovo=='a' || slovo=='e' ||
            slovo=='i' || slovo=='o' || slovo =='u')
        printf("Slovo %c je samoglasnik\n", slovo);
    else
        printf("Slovo %c je suglasnik\n", slovo);
    return 0;
}
