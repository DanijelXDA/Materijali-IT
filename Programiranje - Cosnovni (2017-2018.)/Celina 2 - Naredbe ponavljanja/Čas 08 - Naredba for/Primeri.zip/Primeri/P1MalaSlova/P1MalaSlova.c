#include <stdio.h>
#include <stdlib.h>

int main()
{
    char c;
    
    for (c = 'a'; c <= 'z'; c++)
        printf("%c ", c);
    
    return 0;
}

