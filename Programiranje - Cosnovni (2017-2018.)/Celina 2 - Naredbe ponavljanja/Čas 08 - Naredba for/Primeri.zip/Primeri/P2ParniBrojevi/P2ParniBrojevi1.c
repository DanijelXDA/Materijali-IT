#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;

    printf("Parni brojevi iz intervala od 100 do 1 su: ");

    for (i = 100; i >= 1; i--)
       if (i % 2 == 0)
         printf("%i ", i);

    return 0;
}
