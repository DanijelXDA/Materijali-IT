#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i;

    printf("Parni brojevi iz intervala od 100 do 1 su: ");

    for (i = 50; i >= 1; i--)
       printf("%i ", 2 * i);

    return 0;
}
