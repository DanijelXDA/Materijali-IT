#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, zbir, i, broj;
    float as;

    printf("Koliko brojeva zelite da unesete: ");
    scanf("%i", &n);

    zbir = 0;
    for (i = 1; i <= n; i++){
       printf("Unesite %i. broj: ", i);
       scanf("%i", &broj);
       zbir += broj;
    }

    as = (float) zbir / n;

    printf("Aritmeticka sredina je %.2f.\n", as);

    return 0;
}
