#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, m, k;

    printf("Unesite cele brojeve n i m: ");
    scanf("%i %i", &n, &m);

    printf("Unesite broj decimala k: ");
    scanf("%i", &k);

    printf("Kolicnik je %i.", n / m);

    n = n % m;
    for (i = 1; i <= k; i++) {
       n = n * 10;
       printf("%i", n / m);
       n = n % m;
    }

    printf("\n");

    return 0;
}
