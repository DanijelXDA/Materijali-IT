#include <stdio.h>
#include <stdlib.h>

int main()
{
    char slovo;

    for (slovo = 'A'; slovo <= 'Z'; slovo++)
       printf("%c: %i\n", slovo, slovo);

    return 0;
}
