#include <stdio.h>
#include <stdlib.h>

int main()
{
    char slovo;

    for(slovo = 'A'; slovo <= 'Z'; slovo++)
        printf("%c  ", slovo);

    printf("\n");

    for(slovo = 'A'; slovo <= 'Z'; slovo++)
        printf("%i ", slovo);

    printf("\n");

    return 0;
}
