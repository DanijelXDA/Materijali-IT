#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, m, n, suma = 0;

    printf("Unesite cele brojeve m i n (m <= n): ");
    scanf("%i %i", &m, &n);

    for (i = m; i <= n; i++)
        suma += i;

    printf("Zbir svih brojeva iz intervala [%i, %i] je %i.\n", m, n, suma);

    return 0;
}
