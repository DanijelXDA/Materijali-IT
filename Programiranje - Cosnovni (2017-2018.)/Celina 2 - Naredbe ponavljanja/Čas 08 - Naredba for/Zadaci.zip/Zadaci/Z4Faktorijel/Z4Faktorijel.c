#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, fakt = 1;

    printf("Unesite prirodan broj: ");
    scanf("%i", &n);

    for (i = 1; i <= n; i++)
        fakt *= i;

    printf("%i! = %i\n", n, fakt);

    return 0;
}
