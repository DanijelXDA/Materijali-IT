#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int n, i, nKoren;

    printf("Uneti prirodan broj: ");
    scanf("%i", &n);

    nKoren = sqrt(n);

    printf("%i",n);
    for(i = 1; i <= nKoren; i++)
        if(n % i == 0)
            printf(" = %i * %i", i, n / i);

    printf("\n");

    return 0;
}
