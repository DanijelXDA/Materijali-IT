#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, t, maxT;

    printf("Za koliko dana zelite da unesete temperature: ");
    scanf("%i", &n);

    printf("Unesite temperaturu za 1. dan: ");
    scanf("%i", &t);

    maxT = t;
    for (i = 2; i <= n; i++) {
        printf("Unesite temperaturu za %i. dan: ", i);
        scanf("%i", &t);
        if (t > maxT)
            maxT = t;
    }

    printf("\nNajvisa temperatura je %i stepeni.\n", maxT);

    return 0;
}
