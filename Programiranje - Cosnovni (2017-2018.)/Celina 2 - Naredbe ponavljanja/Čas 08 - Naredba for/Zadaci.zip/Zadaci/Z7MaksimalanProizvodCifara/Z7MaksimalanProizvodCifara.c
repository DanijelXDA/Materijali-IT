#include <stdio.h>
#include <stdlib.h>

int main()
{
    int m, n, i, cif1, cif2, cif3, proizvod, maxProizvod, maxBroj;

    printf("Unesite dva trocifrena broja m i n (m <= n): ");
    scanf("%i %i", &m, &n);

    if(!(100 <= m && m <= n && n <= 999))
        printf("GRESKA: Nisu uneseni trocifreni brojevi ili je m > n!\n");
    else
    {
        maxProizvod = -1;
        for(i = m; i <= n; i++)
        {
            cif1 = i / 100;
            cif2 = (i / 10) % 10;
            cif3 = i % 10;

            proizvod = cif1 * cif2 * cif3;

            if(proizvod > maxProizvod)
            {
                maxProizvod = proizvod;
                maxBroj = i;
            }
        }

        printf("Broj sa najvecim proizvodom cifara iz intervala [%i, %i] je %i.\n", m, n, maxBroj);
    }

    return 0;
}
