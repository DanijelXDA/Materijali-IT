#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, f1, f2, fn;

    printf("Unesite prirodan broj: ");
    scanf("%i", &n);

    f1 = 1;
    f2 = 1;
    for (i = 3; i <= n; i++){
        fn = f1 + f2;
        f1 = f2;
        f2 = fn;
    }

    printf("fn(%i) = %i\n", n, fn);

    return 0;
}
