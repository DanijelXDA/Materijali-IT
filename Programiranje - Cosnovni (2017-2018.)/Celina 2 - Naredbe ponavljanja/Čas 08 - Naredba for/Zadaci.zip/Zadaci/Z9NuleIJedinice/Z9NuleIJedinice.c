#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, cifra = 0, brNula = 1, trenutneNule = 0;

    printf("Unesite prirodan broj: ");
    scanf("%i", &n);

    for(i = 1; i <= n; i++)
    {
        if(cifra == 1)
        {
            cifra = 0;
            brNula++; //ovoliko sledecih cifara su nule
            trenutneNule = 1;
        }
        else if(trenutneNule == brNula)
            cifra = 1;
        else
            trenutneNule++;

        printf("%i", cifra);
    }

    printf("\n");

    return 0;
}
