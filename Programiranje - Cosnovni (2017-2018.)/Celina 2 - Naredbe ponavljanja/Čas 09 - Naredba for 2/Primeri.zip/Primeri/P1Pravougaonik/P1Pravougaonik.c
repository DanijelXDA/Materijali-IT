#include <stdio.h>
#include <stdlib.h>

int main()
{
    int m, n, i, j;

    printf("Unesite dimenzije pravougaonika: ");
    scanf("%i %i", &m, &n);

    for (i = 1; i <= m; i++){
        for(j = 1; j <= n; j++)
            printf("0 ");
        printf("\n");
    }

    return 0;
}
