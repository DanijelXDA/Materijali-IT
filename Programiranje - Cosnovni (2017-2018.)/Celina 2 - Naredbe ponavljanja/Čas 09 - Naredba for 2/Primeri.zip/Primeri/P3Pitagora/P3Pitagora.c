#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j, k;

    printf("Unesite najveci moguci broj za pitagorine trojke: ");
    scanf("%i", &n);

    printf("Pitagorine trojke su: \n");
    for (i = 1; i <= n - 2; i++){
        for(j = i + 1; j <= n - 1; j++)
            for(k = j + 1; k <= n; k++)
                if (i * i == k * k - j * j)
                    printf("(%i, %i, %i)\n", i, j, k);
    }

    return 0;
}
