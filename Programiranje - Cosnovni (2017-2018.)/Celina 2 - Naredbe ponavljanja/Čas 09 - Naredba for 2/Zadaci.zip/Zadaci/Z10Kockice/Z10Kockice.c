#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j, k;

    printf("Unesite n: ");
    scanf("%i", &n);

    printf("Mogucnosti su: ");
    for (i = 1; i <= 6; i++)
        for(j = 1; j <= i; j++)
            for(k = 1; k <= j; k++)
               if (i + j + k == n)
                   printf("(%i, %i, %i) ", i, j, k);

    return 0;
}
