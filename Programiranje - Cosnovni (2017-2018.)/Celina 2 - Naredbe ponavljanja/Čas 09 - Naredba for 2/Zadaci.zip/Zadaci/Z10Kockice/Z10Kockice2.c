#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j, k;

    printf("Unesite n: ");
    scanf("%i", &n);

    printf("Mogucnosti su: ");
    for (i = 1; i <= 6; i++)
        for(j = 1; j <= i; j++)
        {
            k = n - i - j;
            if (k >= 1 && k <= j)
               printf("(%i, %i, %i) ", i, j, k);
        }

    return 0;
}
