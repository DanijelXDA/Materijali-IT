#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j;

    for (i = 1; i <= 9; i++)
        for(j = 0; j <= 9; j++)
            if(i > j)
                printf("%i%i ", i, j);

    return 0;
}
