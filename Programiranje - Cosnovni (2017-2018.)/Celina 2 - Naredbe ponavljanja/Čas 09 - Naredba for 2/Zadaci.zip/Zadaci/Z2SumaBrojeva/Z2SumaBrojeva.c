#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, suma = 0;

    for (i = 1; i <= 9; i++)
        for(j = 0; j <= 9; j++)
            if(i < j * 2)
                suma += 10 * i + j;

    printf("Suma je %i.\n", suma);

    return 0;
}
