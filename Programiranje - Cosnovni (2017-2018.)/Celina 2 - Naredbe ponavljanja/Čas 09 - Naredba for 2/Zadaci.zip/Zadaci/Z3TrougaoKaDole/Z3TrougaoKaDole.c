#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j, k;

    printf("Unesite broj linija trougla: ");
    scanf("%i", &n);

    for (i = n; i >= 1; i--)
    {
        for (j = 0; j <= n - i; j++)
            printf(" ");

        for (k = i; k >= 1; k--)
            printf("X ");

        printf("\n");
    }

    return 0;
}
