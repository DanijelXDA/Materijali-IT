#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j;

    printf("Unesite velicinu tablice: ");
    scanf("%i", &n);

    for (i = 1; i <= n; i++)
    {
        for(j = 1; j <= n; j++)
            printf("%3i", i * j);

        printf("\n");
    }

    return 0;
}
