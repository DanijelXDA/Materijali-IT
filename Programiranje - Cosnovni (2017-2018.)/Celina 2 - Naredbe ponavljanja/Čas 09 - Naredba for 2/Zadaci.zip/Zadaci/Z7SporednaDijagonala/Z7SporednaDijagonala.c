#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j;

    printf("Unesite broj vrsta i kolona: ");
    scanf("%i", &n);

    for (i = 1; i <= n; i++)
    {
        for(j = 1; j <= n; j++)
            if(i + j > n + 1)
                printf("+ ");
            else
                printf("- ");

        printf("\n");
    }

    return 0;
}
