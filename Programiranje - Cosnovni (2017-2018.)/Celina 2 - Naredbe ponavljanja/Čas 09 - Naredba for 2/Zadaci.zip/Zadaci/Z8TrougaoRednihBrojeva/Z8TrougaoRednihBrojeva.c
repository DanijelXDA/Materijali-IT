#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j, br = 0;

    printf("Unesite broj linija trougla: ");
    scanf("%i", &n);

    for (i = 1; i <= n; i++)
    {
        for(j = 1; j <= i; j++)
        {
            br++;
            printf("%3i", br);
        }

        printf("\n");
    }

    return 0;
}
