#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, zbir = 0, fakt = 1;

    printf("Unesite n: ");
    scanf("%i", &n);

    for (i = 1; i <= n; i++)
    {
        fakt *= i;
        zbir += fakt;
    }

    printf("Suma faktorijela brojeva ");
    for (i = 1; i < n; i++)
        printf("%i, ", i);
    printf("%i je %i.\n", n, zbir);

    return 0;
}
