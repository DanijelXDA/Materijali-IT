#include <stdio.h>
#include <stdlib.h>

int main()
{
    int broj, zbir = 0;

    printf("Unesite broj (0 za kraj programa): ");
    scanf("%i", &broj);

    while(broj != 0)
    {
        zbir += broj;
        printf("Unesite broj (0 za kraj programa): ");
        scanf("%i", &broj);
    }

    printf("Zbir je: %i\n", zbir);

    return 0;
}
