#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, zbir = 0, trenutniBroj = 0;

    printf("Unesite broj n: ");
    scanf("%i", &n);

    while(zbir <= n)
    {
        trenutniBroj++;
        zbir += trenutniBroj;
    }

    printf("Treba sabrati prvih %i celih brojeva.\n", trenutniBroj);

    return 0;
}
