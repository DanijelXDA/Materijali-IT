#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, brCifara = 0;

    printf("Unesite prirodan broj n: ");
    scanf("%i", &n);

    while(n != 0)
    {
        brCifara++;
        n /= 10;
    }

    printf("Broj cifara je: %i\n", brCifara);

    return 0;
}
