#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int n, koren, br = 2, prost = 1;

    printf("Unestite broj n: ");
    scanf("%i", &n);

    koren = sqrt(n);

    while(prost && br <= koren)
    {
        if (n % br == 0)
            prost = 0;

        br++;
    }

    if (prost)
        printf("Broj je prost\n");
    else
        printf("Broj nije prost\n");

    return 0;
}
