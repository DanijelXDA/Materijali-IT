#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, br = 2, prost = 1;

    printf("Unestite broj n: ");
    scanf("%i", &n);

    while(prost && br * br <= n)
    {
        if (n % br == 0)
            prost = 0;

        br++;
    }

    if (prost)
        printf("Broj je prost\n");
    else
        printf("Broj nije prost\n");

    return 0;
}
