#include <stdio.h>
#include <stdlib.h>

int main()
{
    int broj, brPoz = 0, brNeg = 0;

    printf("Unesite broj (0 za kraj): ");
    scanf("%i", &broj);

    while(broj != 0)
    {
        if(broj > 0)
            brPoz++;
        else
            brNeg++;

        printf("Unesite broj (0 za kraj): ");
        scanf("%i", &broj);
    }

    printf("Uneli ste %i pozitivnih i %i negativnih brojeva.\n", brPoz, brNeg);

    return 0;
}
