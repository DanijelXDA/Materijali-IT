#include <stdio.h>
#include <stdlib.h>

int main()
{
    float suma, kamata, cilj;
    int meseci = 0;

    printf("Uneti pocetnu sumu: ");
    scanf("%f", &suma);
    printf("Uneti ciljnu sumu: ");
    scanf("%f", &cilj);
    printf("Uneti kamatu (u procentima): ");
    scanf("%f", &kamata);

    while(suma < cilj)
    {
        meseci++;
        suma = suma * (1 + kamata * 0.01); //ili suma *= 1 + kamata * 0.01;
    }

    printf("Do ciljne sume cete stici nakon %d meseci.\n", meseci);

    return 0;
}
