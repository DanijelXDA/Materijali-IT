#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, zbir = 0;

    printf("Unesite broj: ");
    scanf("%i", &n);

    while(n != 0)
    {
        zbir += n % 10;
        n /= 10;
    }

    printf("Zbir cifara je: %i\n", zbir);

    return 0;
}
