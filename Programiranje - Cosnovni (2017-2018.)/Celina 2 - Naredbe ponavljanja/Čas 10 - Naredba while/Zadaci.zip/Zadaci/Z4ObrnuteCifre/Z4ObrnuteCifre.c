#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, br = 0;

    printf("Unesite prirodan broj: ");
    scanf("%i", &n);

    while(n != 0)
    {
        br = br * 10 + n % 10; //nije isto sto i br *= 10 + n % 10;
        n /= 10;
    }

    printf("Broj sa obrnutim redosledom cifara je %i.\n", br);

    return 0;
}
