#include <stdio.h>
#include <math.h>

int main()
{
    float x, y, xPret, yPret;
    int brojac = 2;

    printf("Unositi koordinate tacaka:\nx = ");
    scanf("%f", &xPret);
    printf("y = ");
    scanf("%f", &yPret);
    printf("\nx = ");
    scanf("%f", &x);
    printf("y = ");
    scanf("%f", &y);

    while(sqrt(pow(x - xPret, 2) + pow(y - yPret, 2)) <= 10)
    {
        xPret = x;
        yPret = y;

        printf("\nx = ");
        scanf("%f", &x);
        printf("y = ");
        scanf("%f", &y);

        brojac++;
    }

    printf("\nUcitano je %i tacaka.\n", brojac);

    return 0;
}
