#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, suma, novc, kol, i = 1, brojac = 0;

    printf("Uneti sumu novca: ");
    scanf("%d",&suma);
    printf("Koliko razlicitih novcanica imamo na raspolaganju? ");
    scanf("%d",&n);
    printf("Unositi novcanice od najvece ka najmanjoj:\n");

    while(i <= n && suma > 0)
    {
        printf("Uneti %d-tu novcanicu: ", i);
        scanf("%i", &novc);

        kol = suma / novc;
        suma = suma % novc; //moze i suma %= novc;
        brojac += kol;
        i++;

    }

    printf("Za isplatu je korisceno %d novcanica.\n", brojac);

    return 0;
}
