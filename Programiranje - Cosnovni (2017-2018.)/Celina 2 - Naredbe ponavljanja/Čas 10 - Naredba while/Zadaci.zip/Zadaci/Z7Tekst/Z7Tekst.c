#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;
    int brSl = 0, brCif = 0, brRaz = 0, brOst = 0;

    printf("Unesite tekst znak po znak, a za kraj unesite tacku: ");
    scanf("%c", &ch);

    while (ch != '.')
    {
        if (ch == ' ')
            brRaz++;
        else if ('0' <= ch && ch <= '9')
            brCif++;
        else if (('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z'))
            brSl++;
        else
            brOst++;

        scanf("%c", &ch);
    }

    printf("U tekstu je bilo %i slova, %i cifara, %i razmaka i %i ostalih znakova.\n", brSl, brCif, brRaz, brOst);

    return 0;
}
