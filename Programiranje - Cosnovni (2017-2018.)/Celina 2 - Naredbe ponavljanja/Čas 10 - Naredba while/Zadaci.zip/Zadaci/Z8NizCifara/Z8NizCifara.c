#include <stdio.h>
#include <stdlib.h>

int main()
{
    int c1 = 2, c2 = 0, c3 = 1, c4 = 8, c5, brojac = 1;

    while(!(c1 == 2 && c2 == 3 && c3 == 8 && c4 == 3))
    {
        c5 = (c1 + c2 + c3 + c4) % 10;
        c1 = c2;
        c2 = c3;
        c3 = c4;
        c4 = c5;
        brojac++;
    }

    printf("Cetvorka 2, 3, 8, 3 se pojavljuje od %i. pozicije.\n", brojac);

    return 0;
}
