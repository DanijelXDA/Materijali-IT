#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, pom;

    printf("Unesite a: ");
    scanf("%i", &a);
    printf("Unesite b: ");
    scanf("%i", &b);

    while(a != 0)
    {
        if (a < b)
        {
            pom = a;
            a = b;
            b = pom;
        }
        a -= b;
    }

    printf("Najveci zajednicki delitelj je: %i\n", b);

    return 0;
}
