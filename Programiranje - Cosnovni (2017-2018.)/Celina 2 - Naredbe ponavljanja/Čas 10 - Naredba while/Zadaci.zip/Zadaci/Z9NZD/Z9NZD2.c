#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c, pom;

    printf("Unesite a: ");
    scanf("%i", &a);
    printf("Unesite b: ");
    scanf("%i", &b);

    if(a < b)
    {
        pom = a;
        a = b;
        b = pom;
    }

    while(c != 0)  //nema potrebe da svaki put proveravamo da li je a>=b jer je b dobijen kao ostatak pri deljenju s a
    {
        c = a % b;
        a = b;
        b = c;
    }

    printf("Najveci zajednicki delitelj je: %i\n", a);

    return 0;
}
