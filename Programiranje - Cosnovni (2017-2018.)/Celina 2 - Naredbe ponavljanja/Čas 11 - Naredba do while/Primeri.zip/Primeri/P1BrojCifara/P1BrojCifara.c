#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, br = 0;

    printf("Unesite n: ");
    scanf("%i", &n);

    do
    {
        br++;
        n /= 10;
    }
    while (n != 0);

    printf("Broj cifara unetog broja je %i.\n", br);

    return 0;
}
