#include <stdio.h>
#include <stdlib.h>

int main()
{
    char ch;
    int broj = 0;

    printf("Unesite broj znak po znak: ");

    do
    {
        fflush(stdin);
        scanf("%c", &ch);//ili ch = getchar();

        if ('0' <= ch && ch <= '9')
            broj = broj * 10 + (ch - '0');
    }
    while('0' <= ch && ch <= '9');

    if (ch == '.')
        printf("Uneli ste broj: %d", broj);
    else
        printf("Uneli ste pogresan znak: %c", ch);

    return 0;
}
