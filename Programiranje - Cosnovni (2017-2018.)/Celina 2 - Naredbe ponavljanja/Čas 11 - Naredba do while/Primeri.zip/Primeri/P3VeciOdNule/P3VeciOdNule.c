#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;

    do
    {
        printf("Unesite n: ");
        scanf("%i", &n);

        if (n <= 0)
            printf("Broj mora biti veci od 0!\n");
    }
    while (n <= 0);

    printf("Uneli ste broj %i\n", n);

    return 0;
}
