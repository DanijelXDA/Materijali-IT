#include <stdio.h>
#include <stdlib.h>

int main()
{
    float rez;
    int n;
    char ch;

    printf("Unesite broj: ");
    scanf("%d", &n);
    rez = n;

    do
    {
        printf("Unesite operator: ");
        fflush(stdin);
        scanf("%c", &ch);

        if(ch != '=')
        {
            printf("Unesite broj: ");
            scanf("%d", &n);
        }

        switch(ch)
        {
           case '+': rez += n;
                     break;
           case '-': rez -= n;
                     break;
           case '*': rez *= n;
                     break;
           case '/': rez /= n;
                     break;
        }
    }
    while(ch != '=');

    printf("Rezultat je: %.2f\n", rez);

    return 0;
}
