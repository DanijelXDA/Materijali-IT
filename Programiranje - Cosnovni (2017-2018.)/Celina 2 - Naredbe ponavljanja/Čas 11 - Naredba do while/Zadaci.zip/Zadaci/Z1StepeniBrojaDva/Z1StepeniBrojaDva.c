#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, rez = 2, stepen = 1;

    printf("Unesite n: ");
    scanf("%d", &n);

    do
    {
        printf("%d ", rez);
        rez *= 2;
        stepen++;
    }
    while(stepen <= n);

    return 0;
}
