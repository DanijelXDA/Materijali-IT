#include <stdio.h>

int main()
{
    int n, i = 1;

    printf("Unesite prirodan broj n: ");
    scanf("%d", &n);

    do
    {
        printf("%d ", i * i);
        i++;
    }
    while(i <= n);

    return 0;
}
