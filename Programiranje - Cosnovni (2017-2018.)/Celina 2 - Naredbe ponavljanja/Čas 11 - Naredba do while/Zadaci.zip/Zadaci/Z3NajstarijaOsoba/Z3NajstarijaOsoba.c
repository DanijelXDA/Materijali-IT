#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int TEKUCA_GODINA = 2018;
    int godina, minGodina = -1;

    printf("Unosite godine rodjenja korisnika (0 za kraj unosa):\n");

    do
    {
        scanf("%d", &godina);

        if(minGodina == -1 || (godina < minGodina && godina != 0))
            minGodina = godina;
    }
    while(godina != 0);

    printf("Najstarija osoba ima %d godina.\n", TEKUCA_GODINA - minGodina);

    return 0;
}
