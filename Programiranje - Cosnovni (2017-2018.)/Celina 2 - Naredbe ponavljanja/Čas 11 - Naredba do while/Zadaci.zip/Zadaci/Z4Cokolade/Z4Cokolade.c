#include <stdio.h>
#include <stdlib.h>

int main()
{
    int novac, cena, broj = 0, suma = 0;

    printf("Unesite kolicinu para: ");
    scanf("%d", &novac);

    do
    {
        printf("Unesite cenu cokolade: ");
        scanf("%d", &cena);

        suma += cena;
        broj++;
    }
    while(suma <= novac);

    printf("Kupac moze da kupi %d cokolada.\n", broj - 1);

    return 0;
}
