#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, zbir = 0;

    do
    {
        printf("Unesite broj koji ima tri ili vise cifara: ");
        scanf("%d", &n);

        if(n < 100)
            printf("Greska!\n");
    }
    while(n < 100);

    do
    {
        zbir += n % 10;
        n /= 10;
    }
    while(n != 0);

    printf("Zbir cifara je %d.\n", zbir);

    return 0;
}
