#include <stdio.h>
#include <stdlib.h>

int main()
{
    float tezina, visina, bmi;
    char pol;

    do
    {
        printf("Unesite tezinu u kg: ");
        scanf("%f", &tezina);

        if(tezina <= 0)
            printf("Tezina mora biti pozitivan broj!\n");
    }
    while(tezina <= 0);

    do
    {
        printf("Unesite visinu u m: ");
        scanf("%f", &visina);

        if(visina <= 0)
            printf("Visina mora biti pozitivan broj!\n");
    }
    while(visina <= 0);

    do
    {
        printf("Unesite pol (m / z): ");
        fflush(stdin);
        scanf("%c", &pol);

        if(!(pol == 'm' || pol == 'z')) //uslov moze ovako
            printf("Morate uneti m ili z!\n");
    }
    while(pol != 'm' && pol != 'z'); //a moze i ovako

    bmi = tezina / (visina * visina);

    if(pol == 'm' && bmi <= 20.7 || pol == 'z' && bmi <= 19.1)
    {
        printf("BMI prenizak");
    }
    else if(pol == 'm' && bmi > 20.7 && bmi <= 26.4 || pol == 'z' && bmi > 19.1 && bmi <= 25.8)
    {
        printf("BMI idealan");
    }
    else if(pol == 'm' && bmi > 26.4 && bmi <= 27.8 || pol == 'z' && bmi > 25.8 && bmi <= 27.3)
    {
        printf("BMI malo iznad normale");
    }
    else if(pol == 'm' && bmi > 27.8 && bmi <= 31.1 || pol == 'z' && bmi > 27.3 && bmi <= 32.2)
    {
        printf("BMI visok");
    }
    else if(pol == 'm' && bmi > 31.1 && bmi <= 45.4 || pol == 'z' && bmi > 32.2 && bmi <= 44.8)
    {
        printf("BMI previsok");
    }
    else
    {
        printf("BMI izrazito visok");
    }

    printf(" (BMI = %.1f)\n", bmi);

    return 0;
}
