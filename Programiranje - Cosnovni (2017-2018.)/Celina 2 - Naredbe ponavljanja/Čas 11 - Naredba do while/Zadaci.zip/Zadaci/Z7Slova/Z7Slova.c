#include <stdio.h>
#include <stdlib.h>

int main()
{
    char odg, znak;

    do
    {
        printf("Unesite znak: ");
        fflush(stdin);
        scanf("%c", &znak); // ili znak = getchar();

        printf("Uneli ste znak %c\n", toupper(znak));

        do
        {
            printf("Da li zelite ponovo (d/n)?");
            fflush(stdin);
            scanf("%c", &odg); // ili odg = getchar();
        }
        while(odg != 'n' && odg != 'd');
    }
    while(odg != 'n');

    return 0;
}
