#include <stdio.h>

int main()
{
    int izbor;
    float a, b, c, s;

    do
    {
        printf("\n\nOdaberite opciju: ");
        printf("\n\t1. Trougao");
        printf("\n\t2. Kvadrat");
        printf("\n\t3. Pravougaonik");
        printf("\n\t4. Izlaz\n");
        printf("\n\Izbor: ");
        scanf("%d", &izbor);

        switch(izbor)
        {
            case 1:
                printf("\nUnesite stranice trougla: ");
                scanf("%f %f %f", &a, &b, &c);
                s = (a + b + c) / 2;
                s = s * (s - a) * (s - b) * (s - c);
                printf("Povrsina trougla je: %f", s);
                break;
            case 2:
                printf("\nUnesite stranicu kvadrata: ");
                scanf("%f", &a);
                printf("Povrsina kvadrata je: %f", a * a);
                break;
            case 3:
                printf("\nUnesite stranice pravougaonika: ");
                scanf("%f %f", &a, &b);
                printf("Povrsina pravougaonika je: %f", a * b);
                break;
            case 4:
                printf("\nKraj programa.\n");
                break;
            default:
                printf("\nMorate odabrati neki od brojeva 1 - 4!");
        }
    }
    while(izbor != 4);

    return 0;
}
