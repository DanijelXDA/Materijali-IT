#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    int n, br, brPokusaja = 0;

    srand(time(0)); //postavljanje semena randoma

    br = rand() % 100 + 1;
    //printf("Zamisljeni broj je %d.\n", br);

    do
    {
        printf("Unesite broj: ");
        scanf("%d", &n);

        if(n > br)
            printf("Uneli ste prevelik broj!\n\n");
        else if(n < br)
            printf("Uneli ste premali broj!\n\n");

        brPokusaja++;
    }
    while(n != br);

    printf("Pogodili ste iz %d pokusaja\n", brPokusaja);

    return 0;
}
