#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        printf("Unesite %d. clan niza: ", i + 1);  // jer nas niz krece od nule
        scanf("%d", &a[i]);
    }

    printf("\nKvadrati unesenih brojeva u niz a su:\n");
    for(i = 0; i < n; i++)
    {
        printf("k[%d] = %d\n", i, a[i] * a[i]);
    }

    printf("\nKvadrati unesenih brojeva u niz a ispisani obrnuto su:\n");
    for(i = n - 1; i >= 0; i--)
    {
        printf("k[%d] = %d\n", i, a[i] * a[i]);
    }

    return 0;
}
