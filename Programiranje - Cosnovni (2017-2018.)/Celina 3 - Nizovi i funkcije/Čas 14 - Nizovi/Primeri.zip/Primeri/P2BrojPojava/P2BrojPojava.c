#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, x, br_pojava, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("\nUnesite clanove niza:\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("\nUnesite broj koji trazite: ");
    scanf("%d", &x);

    br_pojava = 0;
    for(i = 0; i < n; i++)
    {
        if(a[i] == x)
        {
            br_pojava++;
        }
    }
    printf("\nBroj pojava broja %d je %d.\n", x, br_pojava);

    return 0;
}
