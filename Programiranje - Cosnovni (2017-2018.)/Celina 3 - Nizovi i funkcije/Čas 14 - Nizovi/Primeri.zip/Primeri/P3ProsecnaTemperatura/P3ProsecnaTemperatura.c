#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, brojac;
    float prosek, suma, t[100];

    printf("Unesite broj dana (broj <= 100): ");
    scanf("%d", &n);

    for(i = 0; i < n; i++)
    {
        printf("Unesite temperaturu za %d. dan: ", i + 1);
        scanf("%f", &t[i]);
    }

    suma = 0;
    for(i = 0; i < n; i++)
    {
        suma += t[i];
    }
    prosek = suma / n;

    brojac = 0;
    for(i = 0; i < n; i++)
    {
        if(t[i] > prosek)
        {
            brojac++;
        }
    }
    printf("\n%d dana je temeratura bila iznad proseka.\n", brojac);

    return 0;
}
