#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, minimum, pozicija, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("\nUnesite clanove niza:\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    minimum = a[0];
    pozicija = 0;
    for(i = 1; i < n; i++)  // ne moramo kretati od 0 jer smo ga proglasili za trenutni minimum
    {
        if(a[i] < minimum){
            minimum = a[i];
            pozicija = i;
        }
    }
    printf("\nElement koji ima najmanju vrednost je %d i nalazi se na poziciji %d.\n", minimum, pozicija);

    return 0;
}
