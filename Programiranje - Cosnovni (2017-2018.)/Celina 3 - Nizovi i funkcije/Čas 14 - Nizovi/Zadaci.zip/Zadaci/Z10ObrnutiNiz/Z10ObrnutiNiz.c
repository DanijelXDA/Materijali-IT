#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, pom, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("Unesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    for(i = 0; i < n / 2; i++)
    {
        pom = a[i];
        a[i] = a[n - i - 1];
        a[n - i - 1] = pom;
    }

    printf("\nObrnuti niz izgleda ovako:\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = %d\n", i, a[i]);
    }

    return 0;
}
