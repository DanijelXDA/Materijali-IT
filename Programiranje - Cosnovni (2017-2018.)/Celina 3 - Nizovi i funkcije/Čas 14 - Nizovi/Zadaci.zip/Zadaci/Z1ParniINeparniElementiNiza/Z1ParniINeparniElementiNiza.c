#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, brojParnih, brojNeparnih, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("\nUnesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    brojParnih = 0;
    brojNeparnih = 0;
    for(i = 0; i < n; i++)
    {
        if(a[i] % 2 == 0)
        {
            brojParnih++;
        }
        else
        {
            brojNeparnih++;
        }
    }
    printf("\nBroj parnih brojeva je %d, a neparnih %d.\n", brojParnih, brojNeparnih);

    return 0;
}
