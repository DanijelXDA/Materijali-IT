#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, ukupno;
    float prosek;
    int ocene[5];

    printf("Unesite koliko ucenika je dobilo koju ocenu.\n");
    for(i = 0; i < 5; i++)
    {
        printf("Koliko ucenika je dobilo ocenu %d: ", i + 1);
        scanf("%d", &ocene[i]);
    }

    prosek = 0;
    ukupno = 0;
    for(i = 0; i < 5; i++)
    {
        prosek += (i + 1) * ocene[i];
        ukupno += ocene[i];
    }
    prosek /= ukupno;

    printf("\nProsecna ocena razreda je %.2f. U razredu je %d ucenika.\n", prosek, ukupno);

    return 0;
}
