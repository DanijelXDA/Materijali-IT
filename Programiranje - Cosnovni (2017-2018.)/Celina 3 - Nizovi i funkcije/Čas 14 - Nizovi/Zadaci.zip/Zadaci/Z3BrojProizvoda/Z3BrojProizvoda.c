#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, broj;
    float cena[100], ukupno, racun;

    printf("Unesite broj proizvoda (broj <= 100): ");
    scanf("%d", &n);

    for(i = 0; i<n; i++)
    {
        printf("Unesite cenu %d. proizvoda: ", i + 1);
        scanf("%f", &cena[i]);
    }

    printf("Unesite koliko imate para: ");
    scanf("%f", &ukupno);

    racun = 0;
    broj = 0;
    while(broj < n && ukupno >= racun + cena[broj])
    {
        racun += cena[broj];
        broj++;
    }

    printf("\nMozete da kupite ukupno %d proizvoda.\n", broj);

    return 0;
}
