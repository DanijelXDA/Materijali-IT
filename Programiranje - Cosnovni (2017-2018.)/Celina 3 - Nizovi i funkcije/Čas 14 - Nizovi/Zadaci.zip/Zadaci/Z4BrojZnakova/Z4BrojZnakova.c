#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a[100];
    int i, n, cifre, slova, ostali;

    printf("Unesite broj znakova (broj < 100): ");
    scanf("%d", &n);

    printf("Unesite znakove.\n");
    for (i = 0; i < n; i++)
    {
        printf("%d. znak: ", i + 1);
        fflush(stdin);
        scanf("%c", &a[i]);
    }

    cifre = 0;
    slova = 0;
    ostali = 0;
    for (i = 0; i < n; i++)
    {
        if('0' <= a[i] && a[i] <= '9')
        {
            cifre++;
        }
        else if('A' <= a[i] && a[i] <= 'Z' || 'a' <= a[i] && a[i] <= 'z')
        {
            slova++;
        }
        else
        {
            ostali++;
        }
    }

    printf("\nMedju unetim znakovima ima %d cifara, %d slova i %d ostalih znakova.\n", cifre, slova, ostali);

    return 0;
}
