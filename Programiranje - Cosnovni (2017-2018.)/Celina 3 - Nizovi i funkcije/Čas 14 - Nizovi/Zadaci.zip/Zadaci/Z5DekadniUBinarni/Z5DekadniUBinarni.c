#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, dek, tmp, brCif, bin[32];

    printf("Unesite broj u osnovi 10: ");
    scanf("%d", &dek);

    tmp = dek;
    brCif = 0;
    do  // algoritam pretvaranja dekadnog u binarni broj
    {
       bin[brCif] = tmp % 2;
       brCif++;
       tmp /= 2;
    }
    while(tmp != 0);

    printf("Broj %d u osnovi 2 izgleda ovako: ", dek);
    for(i = brCif - 1; i >= 0; i--)
    {
        printf("%d", bin[i]);
        if(i % 8 == 0)  // radi preglednijeg ispisa na nivou bajtova
        {
            printf(" ");
        }
    }

    return 0;
}
