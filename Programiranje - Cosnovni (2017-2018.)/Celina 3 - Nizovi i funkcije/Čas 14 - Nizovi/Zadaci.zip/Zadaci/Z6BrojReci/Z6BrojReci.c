#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a[100];
    int i, n, brojReci;

    printf("Unesite recenicu sa najvise 100 znakova i zavrsite je tackom:\n");
    n = 0;
    do
    {
        scanf("%c", &a[n]);
        n++;
    }
    while(a[n - 1] != '.');

    brojReci = 0;
    for(i = 0; i  <n; i++)
    {
        if(a[i] == ' ')
        {
            brojReci++;
        }
    }
    brojReci++;

    printf("\nUkupan broj reci je: %d\n", brojReci);

    return 0;
}
