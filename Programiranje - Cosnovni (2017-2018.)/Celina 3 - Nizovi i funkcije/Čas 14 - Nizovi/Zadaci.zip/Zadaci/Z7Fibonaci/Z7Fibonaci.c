#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, fib[100];

    printf("Unesite n (0 <= n < 100): ");
    scanf("%d", &n);

    fib[0] = 0;  // 1. element dodeljujemo direktno naredbom dodele
    fib[1] = 1;  // 2. element dodeljujemo direktno naredbom dodele
    for (i = 2; i < n; i++)  // krecemo od 3. elementa u nizu zbog fib[i - 2] i racunamo preostale elemente
    {
        fib[i] = fib[i - 1] + fib[i - 2];
    }

    for(i = 0; i < n; i++)
    {
        printf("%d ", fib[i]);
    }

    return 0;
}
