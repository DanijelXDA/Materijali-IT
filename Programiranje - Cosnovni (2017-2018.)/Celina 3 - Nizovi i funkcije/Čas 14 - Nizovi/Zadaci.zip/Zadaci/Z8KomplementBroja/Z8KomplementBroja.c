#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, tmp, brCif, cifre[10];

    printf("Unesite broj n: ");
    scanf("%d", &n);

    tmp = n;
    brCif = 0;
    do
    {
        cifre[brCif] = tmp % 10;
        tmp /= 10;
        brCif++;
    }
    while(tmp != 0);

    for(i = 0; i < brCif; i++)
    {
        cifre[i] = 9 - cifre[i];
    }

    printf("\nKomplement broja %d je broj ", n);
    for(i = brCif - 1; i >= 0; i--)
    {
        printf("%d", cifre[i]);
    }
    printf(".\n");

    return 0;
}
