#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, pom, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("Unesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", &a[i]);
    }

    pom = a[0];  // cuvamo vrednost clana kog prvog menjamo
    for(i = 0; i < n - 1; i++)
    {
        a[i] = a[i + 1];
    }
    a[n - 1] = pom;  // direktno mu dodeljujemo sacuvanu vrednost naredbom dodele

    printf("\nNiz posle pomeranja:\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = %d\n", i, a[i]);
    }

    return 0;
}
