#include <stdio.h>
#include <stdlib.h>

int main()
{
    int god[] = {1998, 2002, 2000, 2001, 2002};
    int ocene[5] = {3, 5, 2, 5, 4};
    float visine[5] = {173.8, 182.1, 201.2};
    int i, duzina;

    printf("Naziv niza \t Bajtova \t Elemenata \n");
    printf("god \t\t %i \t\t %i \n", sizeof(god), sizeof(god) / sizeof(god[0]));
    printf("ocene \t\t %i \t\t %i \n", sizeof(ocene), sizeof(ocene) / sizeof(ocene[0]));
    printf("visine \t\t %i \t\t %i \n", sizeof(visine), sizeof(visine) / sizeof(visine[0]));

    printf("\nDemonstracija ponasanja delimicne inicijalizacije niza visine: \n");
    duzina = sizeof(visine) / sizeof(visine[0]);
    for(i = 0; i < duzina; i++)
    {
        printf("visine[%i] = %.1f \n", i, visine[i]);
    }

    return 0;
}
