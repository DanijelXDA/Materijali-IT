#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, brojProizvoda[100];
    float cenaProizvoda[100], ukupnaCena;

    printf("Unesite broj proizvoda koje ste kupili: ");
    scanf("%i", &n);

    for(i = 0; i < n; i++)
    {
        printf("\nUnesite broj komada za proizvod broj %i: ", i + 1);
        scanf("%i", &brojProizvoda[i]);
        printf("Unesite cenu po komadu za proizvod broj %i: ", i + 1);
        scanf("%f", &cenaProizvoda[i]);
    }

    ukupnaCena = 0.0;  // moze i ukupnaCena = 0;
    for (i = 0; i < n; i++)
    {
        ukupnaCena += brojProizvoda[i] * cenaProizvoda[i];
    }

    printf("\nVas ukupan racun je %.2f dinara.\n", ukupnaCena);

    return 0;
}
