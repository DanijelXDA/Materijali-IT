#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, a[100], b[100], c[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%i", &n);

    printf("\nUnesite clanove niza a\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    printf("\nUnesite clanove niza b\n");
    for(i = 0; i < n; i++)
    {
        printf("b[%i] = ", i);
        scanf("%i", &b[i]);
    }

    for(i = 0; i < n; i++)
    {
        c[i] = a[i] + b[i];
    }

    printf("\nNiz c izgleda ovako\n");
    for(i = 0; i < n; i++)
    {
        printf("c[%i] = %i\n", i, c[i]);
    }

    return 0;
}
