#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, n, brojac, a[100], b[100];

    printf("Unesite broj clanova niza (broj <= 100): \n");
    scanf("%i", &n);

    printf("\nUnesite clanove niza a\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    printf("\nUnesite clanove niza b\n");
    for(i = 0; i < n; i++)
    {
        printf("b[%i] = ", i);
        scanf("%i", &b[i]);
    }

    brojac = 0;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < n; j++)
        {
            if(a[i] > b[j])
            {
                brojac++;
            }
        }
    }

    printf("\nIma %d parova, takvih da je a[i] > b[j]\n", brojac);

    return 0;
}
