#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, b[5], a[100];

    printf("Unesite broj ucenika (broj <= 100): ");
    scanf("%i", &n);

    printf("\nUnesite ocene ucenika\n");
    for(i = 0; i < n; i++)
    {
        printf("Ucenik %i: ", i + 1);
        scanf("%i", &a[i]);
    }

    for(i = 0; i < 5; i++)  // umesto ovog smo mogli odraditi inicijalizaciju niza b prilikom njegovog definisanja
    {
        b[i] = 0;
    }

    for(i = 0; i < n; i++)
    {
        b[a[i] - 1]++;
    }

    printf("\nBroj ocena je sledeci:\n");
    for(i = 0; i < 5; i++)
    {
        printf("Ocena %i ima %i\n", i + 1, b[i]);
    }

    return 0;
}
