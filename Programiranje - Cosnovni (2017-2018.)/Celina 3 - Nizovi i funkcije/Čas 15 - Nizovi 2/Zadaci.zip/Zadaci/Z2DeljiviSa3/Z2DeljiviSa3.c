#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, brojDeljivih, b_brojac, a[100], b[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%i", &n);

    printf("\nUnesite clanove niza a\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    brojDeljivih = 0;
    for(i = 0; i < n; i++)
    {
        if(a[i] % 3 == 0)
        {
            b[brojDeljivih] = a[i];
            brojDeljivih++;
        }
    }

    printf("\nClanovi novog niza su:\n");
    for(i = 0; i < brojDeljivih; i++)
    {
        printf("b[%i] = %i\n", i, b[i]);
    }

    return 0;
}
