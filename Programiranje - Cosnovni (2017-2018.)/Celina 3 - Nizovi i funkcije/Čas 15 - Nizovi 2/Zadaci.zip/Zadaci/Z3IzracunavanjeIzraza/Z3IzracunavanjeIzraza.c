#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, rez, a[100], b[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%i", &n);

    printf("\nUnesite clanove niza a\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    printf("\nUnesite clanove niza b\n");
    for(i = 0; i < n; i++)
    {
        printf("b[%i] = ", i);
        scanf("%i", &b[i]);
    }

    rez = 0;
    for(i = 0; i < n; i++)
    {
        rez += a[i] * b[n - i - 1];
    }

    printf("\nVrednost izraza je %i.\n", rez);

    return 0;
}
