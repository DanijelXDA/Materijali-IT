#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, brPoz, brNeg, a[100], poz[100], neg[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%i", &n);

    printf("\nUnesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    brPoz = 0;
    brNeg = 0;
    for(i = 0; i < n; i++)
    {
        if(a[i] >= 0)
        {
            poz[brPoz] = a[i];
            brPoz++;
        }
        else
        {
            neg[brNeg] = a[i];
            brNeg++;
        }
    }

    printf("\nPozitivni (nenegativni) brojevi su:\n");
    for(i = 0; i < brPoz; i++)
    {
        printf("b[%i]=%i\n", i, poz[i]);
    }
    printf("\nNegativni brojevi su:\n");
    for(i=0; i<brNeg; i++)
    {
        printf("c[%i]=%i\n", i, neg[i]);
    }

    return 0;
}
