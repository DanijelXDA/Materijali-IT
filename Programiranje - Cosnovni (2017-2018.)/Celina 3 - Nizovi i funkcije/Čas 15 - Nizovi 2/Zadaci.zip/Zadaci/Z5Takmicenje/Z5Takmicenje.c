#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, sifre[100], sifra1, sifra2, indeks1, indeks2;
    float bodovi[100];

    printf("Unesite broj takmicara na takmicenju (broj <= 100): ");
    scanf("%i", &n);

    for(i = 0; i < n; i++)
    {
        printf("\nUnesite sifru %i. takmicara: ", i + 1);
        scanf("%i", &sifre[i]);
        printf("Unesite njegove osvojene bodove: ");
        scanf("%f", &bodovi[i]);
    }

    printf("\n\nUnesite sifru prvog takmicara: ");
    scanf("%i", &sifra1);
    printf("Unesite sifru drugog takmicara: ");
    scanf("%i", &sifra2);

    indeks1 = -1;
    indeks2 = -1;
    for(i = 0; i < n; i++)
    {
        if(sifre[i] == sifra1)
        {
            indeks1 = i;
        }
        else if(sifre[i] == sifra2)
        {
            indeks2 = i;
        }
    }

    if(indeks1 != -1 && indeks2 != -1)
    {
        if(bodovi[indeks1] > bodovi[indeks2])
        {
            printf("\nPrvi takmicar ima vise bodova od drugog.\n");
        }
        else if(bodovi[indeks1] < bodovi[indeks2])
        {
            printf("\nDrugi takmicar ima vise bodova od prvog.\n");
        }
        else
        {
            printf("\nOba takmicara imaju isti broj bodova.\n");
        }
    }
    else
    {
        printf("Trazeni podaci nisu pronadjeni!\n");
    }

    return 0;
}
