#include <stdio.h>

#define MAX_SIZE 100

int main()
{

    int i, j, tmpBrojac, n, m, a[MAX_SIZE], b[MAX_SIZE], c[MAX_SIZE];

    printf("Unesite velicine nizova a i b: ");
    scanf("%i %i", &n, &m);

    printf("\nUnesite elemente niza a:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%i", &a[i]);
    }

    printf("\nUnesite elemente niza b:\n");
    for(i = 0; i < m; i++)
    {
        scanf("%i", &b[i]);
    }

    i = 0;
    tmpBrojac = 1;
    while(i < m && tmpBrojac > 0)
    {
        tmpBrojac = 0;
        for(j = 0; j < n; j++)
        {
            if(b[i] == a[j])
            {
                tmpBrojac++;
            }
        }
        i++;
    }

    if(i == m && tmpBrojac > 0)
    {
        printf("\nSkup b je podskup skupa a.\n");

    }
    else
    {
        printf("\nSkup b nije podskup skupa a.\n");
    }

    return 0;
}
