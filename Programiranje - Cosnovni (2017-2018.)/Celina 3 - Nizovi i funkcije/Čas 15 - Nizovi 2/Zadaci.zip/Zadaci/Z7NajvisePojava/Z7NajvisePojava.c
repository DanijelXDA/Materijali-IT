#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, n, brPonavljanja, ponavljanjeTrenutnog, trenutniKandidat, kandidat, a[100];

    printf("Unesite broj elemenata niza a (broj <= 100): ");
    scanf("%i", &n);

    printf("\nUnesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    brPonavljanja = 0;
    kandidat = a[0];
    for(i = 0; i < n; i++)
    {
        ponavljanjeTrenutnog = 1;
        trenutniKandidat = a[i];

        for(j = i + 1; j < n; j++)
        {
            if(trenutniKandidat == a[j])
            {
                ponavljanjeTrenutnog++;
            }
        }

        if(ponavljanjeTrenutnog > brPonavljanja)
        {
            brPonavljanja = ponavljanjeTrenutnog;
            kandidat = trenutniKandidat;
        }
    }

    printf("\nBroj koji se najvise ponavlja u nizu je %i i ponavlja se %i puta.\n", kandidat, brPonavljanja);

    return 0;
}
