#include <stdio.h>

#define MAX_SIZE 100

int main()
{

    int i, j, tmpBrojac, n, m, a[MAX_SIZE], b[MAX_SIZE], c[MAX_SIZE];

    printf("Unesite velicine nizova a i b: ");
    scanf("%i %i", &n, &m);

    printf("\nUnesite elemente niza a: \n");
    for(i = 0; i < n; i++)
    {
        printf("a[%i] = ", i);
        scanf("%i", &a[i]);
    }

    printf("\nUnesite elemente niza b: \n");
    for(i = 0; i < m; i++)
    {
        printf("b[%i] = ", i);
        scanf("%i", &b[i]);
    }

    for(i = 0; i < m; i++)
    {
        tmpBrojac = 0;
        for(j = 0; j < n; j++)
        {
            if(b[i] == a[j])
            {
                tmpBrojac++;
            }
        }
        c[i] = tmpBrojac;
    }

    printf("\nElementi niza c:\n");
    for(i = 0; i < m; i++)
    {
        printf("c[%i] = %i\n", i, c[i]);
    }

    return 0;
}
