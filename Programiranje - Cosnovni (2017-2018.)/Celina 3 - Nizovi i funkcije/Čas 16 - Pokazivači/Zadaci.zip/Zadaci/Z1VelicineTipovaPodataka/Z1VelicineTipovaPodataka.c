#include <stdio.h>
#include <stdlib.h>

int main()
{

    printf("Velicina int u bajtima je: %d\n", sizeof(int));
    printf("Velicina int* u bajtima je: %d\n", sizeof(int*));
    printf("Velicina char u bajtima je: %d\n", sizeof(char));
    printf("Velicina char* u bajtima je: %d\n", sizeof(char*));
    printf("Velicina float u bajtima je: %d\n", sizeof(float));
    printf("Velicina float* u bajtima je: %d\n", sizeof(float*));
    printf("Velicina double u bajtima je: %d\n", sizeof(double));
    printf("Velicina double* u bajtima je: %d\n", sizeof(double*));

    return 0;
}
