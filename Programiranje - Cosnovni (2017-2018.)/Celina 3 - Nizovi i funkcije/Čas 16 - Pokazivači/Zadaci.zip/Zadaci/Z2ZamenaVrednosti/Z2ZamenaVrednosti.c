#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;
    int* pom;

    printf("Unesite vrednosti a i b: ");
    scanf("%d %d", &a, &b);

    printf("\nVrednosti pre zamene: a = %d i b = %d\n", a, b);

    pom = &a;

    *pom = *pom + b;
    b = *pom - b;
    *pom = *pom - b;

    printf("\nVrednosti nakon zamene: a = %d i b = %d\n", a, b);

    return 0;
}
