#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x, y, pom;
    int* pokx = &x;
    int* poky = &y;

    printf("Uneti dva cela broja x i y: ");
    scanf("%d %d", pokx, poky); //moze i scanf("%d %d", &x, &y);

    printf("Pocetno stanje:\n");
    printf("broj %d je na adresi %p\n", x, pokx);
    printf("broj %d je na adresi %p\n", y, poky);

    if(pokx > poky && x < y  ||  pokx < poky && x > y)
    {
        pom = x;
        x = y;
        y = pom;
    }

    printf("\nSada je sigurno manji broj ispred veceg u memoriji:\n");
    printf("broj %d je na adresi %p\n", x, pokx);
    printf("broj %d je na adresi %p\n", y, poky);

    return 0;
}
