#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, maxIdx, niz[20];

    printf("Unesite broj elemenata niza [1-20]: ");
    scanf("%d", &n);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < n; i++)
    {
        printf("niz[%d] = ", i);
        scanf("%d", niz + i);
    }

    maxIdx = 0;
    for(i = 1; i < n; i++)
    {
        if(*(niz + i) > *(niz + maxIdx))
        {
            maxIdx = i;
        }
    }

    printf("\nNajveca vrednost niza je %d, nalazi se na poziciji %d i adresa mu je %p\n", *(niz + maxIdx), maxIdx, niz + maxIdx);

    return 0;
}
