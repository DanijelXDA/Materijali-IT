#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

int main()
{
    int i, n, niz[MAX_DUZINA];
    int *pok, *maxPok;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    scanf("%d", &n);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(pok = niz; pok < niz + n; pok++)
    {
        printf("niz[%d] = ", pok - niz);
        scanf("%d", pok);
    }

    maxPok = niz;
    for(pok = niz + 1; pok < niz + n; pok++)
    {
        if(*pok > *maxPok)
        {
            maxPok = pok;
        }
    }

    printf("\nNajveca vrednost niza je %d, nalazi se na poziciji %d i adresa mu je %p\n", *maxPok, maxPok - niz, maxPok);

    return 0;
}
