#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, x, pozicija, a[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("\nUnesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", a + i);
    }

    printf("\nUnesite broj ciju poziciju zelite da pronadjete: ");
    scanf("%d", &x);

    pozicija = -1;
    for(i = 0; i < n; i++)
    {
        if(*(a + i) == x && pozicija == -1)
        {
            pozicija = i;
        }
    }

    if(pozicija != -1)
    {
        printf("\nBroj %d se nalazi na poziciji %d.\n", x, pozicija);
    }
    else
    {
        printf("\nBroj %d se ne nalazi u nizu.\n", x);
    }

    return 0;
}
