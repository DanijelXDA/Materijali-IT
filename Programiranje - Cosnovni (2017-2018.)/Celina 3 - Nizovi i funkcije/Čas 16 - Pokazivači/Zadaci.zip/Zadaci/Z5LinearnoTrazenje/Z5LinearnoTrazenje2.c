#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, x, a[100];
    int *pok, *pozicija;


    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("\nUnesite clanove niza\n");
    for(pok = a; pok < a + n; pok++)
    {
        printf("a[%d] = ", pok - a);
        scanf("%d", pok);
    }

    printf("\nUnesite broj ciju poziciju zelite da pronadjete: ");
    scanf("%d", &x);

    pozicija = a;
    while(pozicija < a + n && *pozicija != x)
    {
        pozicija++;
    }

    if(pozicija < a + n)
    {
        printf("\nBroj %d se nalazi na poziciji %d.\n", x, pozicija - a);
    }
    else
    {
        printf("\nBroj %d se ne nalazi u nizu.\n", x);
    }

    return 0;
}
