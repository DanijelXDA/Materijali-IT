#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, brojNula, a[100], b[100];

    printf("Unesite broj clanova niza (broj <= 100): ");
    scanf("%d", &n);

    printf("\nUnesite clanove niza\n");
    for(i = 0; i < n; i++)
    {
        printf("a[%d] = ", i);
        scanf("%d", a + i);
    }

    brojNula = 0;
    for(i = 0; i < n; i++)
    {
        if(*(a + i) % 2 == 0)
        {
            *(b + i) = *(a + i);
        }
        else
        {
            *(b + i) = 0;
        }

        if(*(b + i) == 0)
        {
            brojNula++;
        }
    }

    printf("\nNovi niz sadrzi %i nula.", brojNula);
    printf("\nClanovi novog niza su:\n");
    for(i = 0; i < n; i++)
    {
        printf("b[%i] = %i\n", i, *(b + i));
    }

    return 0;
}
