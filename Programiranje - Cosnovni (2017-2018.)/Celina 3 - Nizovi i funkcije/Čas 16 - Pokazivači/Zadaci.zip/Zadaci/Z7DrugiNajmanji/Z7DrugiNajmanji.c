#include <stdio.h>
#include <limits.h>

#define MAX_DUZINA 20

int main()
{
	int n, niz[MAX_DUZINA];
    int* minpok;
    int* min2pok;
    int* pok;

	printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
	scanf("%d", &n);

	printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
	for(pok = niz; pok < niz + n; pok++)
    {
        printf("niz[%d] = ", pok - niz);
		scanf("%d", pok);
	}

    minpok = niz;
    min2pok = niz;
    for(pok = niz + 1; pok < niz + n; pok++)
    {
		if(*pok < *minpok)
		{
			min2pok = minpok;
			minpok = pok;
		}
		else if(*pok < *min2pok || (minpok == min2pok && *pok != *min2pok))
		//drugi slucaj je kada se prvi put pojavljuje element razlicit od prvog
        {
            min2pok = pok;
        }
	}
    if(minpok == min2pok)
        printf("\nU nizu se nalazi samo jedna vrednost!\n");
    else
        printf("\nDruga najmanja vrednost u nizu je %d, i nalazi se na poziciji %d.\n", *min2pok, min2pok - niz);

	return 0;
}
