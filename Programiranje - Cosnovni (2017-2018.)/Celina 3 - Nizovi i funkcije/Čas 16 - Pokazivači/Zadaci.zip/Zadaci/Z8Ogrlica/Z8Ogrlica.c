#include <stdio.h>
#include <stdlib.h>

int main()
{
    int ogr[100];
    int *pok1, *pok2;
    int n, brojac, max = 0;

    printf("Unesite broj bisera na ogrlici: ");
    scanf("%d", &n);

    printf("\nUnesite boje bisera (1/2/3):");
    for(pok1 = ogr; pok1 < ogr + n; pok1++)
    {
        scanf("%d", pok1);
    }

    for(pok1 = ogr; pok1 < ogr + n; pok1++)
    {
        pok2 = pok1;
        brojac = 0;
        do
        {
            pok2++;
            brojac++;
            if(pok2 >= ogr + n) //stigli smo do kraja, krecemo ispocetka
            {
                pok2 = ogr;
            }
        }
        while(pok1 != pok2 && *pok1 == *pok2);

        if(brojac > max)
        {
            max = brojac;
        }
    }

    printf("\nNajduzi niz bisera iste boje ima duzinu %d\n", max);

    return 0;
}
