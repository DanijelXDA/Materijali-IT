#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

int main()
{
    int n, brojac, niz[MAX_DUZINA];
    int *pok;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    scanf("%d", &n);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(pok = niz; pok < niz + n; pok++)
    {
        scanf("%d", pok);
    }

    pok = niz;
    brojac = 0;
    while(pok + *pok >= niz  &&  pok + *pok < niz + n  &&  *pok != 0  &&  brojac <= n)
    {
        pok += *pok;
        brojac++;
    }

    if(*pok == 0)
        printf("\nSkakavac se zaustavlja na poziciji %d.\n", pok - niz);
    else if(brojac > n)
        printf("\nSkakavac se vrti ukrug.\n");
    else
        printf("\nSkakavac je iskocio iz niza.\n");

    return 0;
}
