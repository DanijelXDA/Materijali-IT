#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x = 123, y = 456, z = 0;
	int* px = &x;					// Definicija i inicijalizacija pokazivaca
	int* py = &y;
	int* pz;						// Definicija pokazivaca (bez inicijalizacije)

	z = *px + *py;					// Pristup podacima preko pokazivaca (dereferenciranje)
	pz = &z;						// Dodela vrednosti pokazivacu

	// Pristup vrednosti pokazivaca
	printf("Vrednost prvog broja je %d (nalazi se na adresi %p).\n", x, px);
	printf("Vrednost drugog broja je %d (nalazi se na adresi %p).\n", y, py);

	printf("Zbir brojeva %d i %d je %d.\n", x, y, z);
	printf("Zbir brojeva %d i %d je %d. (preko pokazivaca)\n", *px, *py, *pz);

	return 0;
}
