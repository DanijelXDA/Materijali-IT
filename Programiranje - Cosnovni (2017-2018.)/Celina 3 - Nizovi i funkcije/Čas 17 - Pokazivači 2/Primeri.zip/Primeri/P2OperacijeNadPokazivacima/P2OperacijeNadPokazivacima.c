#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x = 125;
	printf("Podatak:     %d\n\n", x);

	int* px = &x;
	printf("Podatak:     %d (preko prvog okazivaca)\n", *px);
	printf("Pokazivac 1: %p\n", px);
	printf("Podatak++:   %d \n", ++(*px));	// Uvecanje vrednosti podatka
	printf("Pokazivac++: %p\n\n", ++px);	// Prelazak na sledecu adresu

	int* py = NULL;							// Inicijalizacija pokazivaca na nultu adresu
	py = px - 1;							// Pokazivacka aritmetika
	printf("Podatak:     %d (preko drugog pokazivaca)\n", *py);
	printf("Pokazivac 2: %p\n", py);
	printf("Podatak--:   %d\n\n", --(*py));

	printf("Podatak:     %d\n", x);

	return 0;
}
