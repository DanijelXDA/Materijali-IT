#include <stdio.h>
#include <stdlib.h>

int main()
{
	void* p = NULL;					// Netipizirani pokazivac

	int ceoBroj = 100;
	p = &ceoBroj;					// Dobija adresu celobrojnog podatka
	//printf("%d\n", *p);			// GRESKA: Pristup podatku pomocu netipiziranog pokazivaca nije moguc bez konverzije tipa
	printf("%d\n", *(int*)p);		// Potrebno je prvo izvrsiti konverziju u pokazivac na poznati tip podataka

	double realanBroj = 111.11;
	p = &realanBroj;				// Dobija adresu realnog podatka
	//printf("%.2f\n", *p);			// GRESKA: Pristup podatku pomocu netipiziranog pokazivaca nije moguc bez konverzije tipa
	printf("%.2f\n", *(double*)p);	// Potrebno je prvo izvrsiti konverziju u pokazivac na poznati tip podataka

	return 0;
}
