#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x = 10, y = 20;
	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	int* pppp;					// Promenljivi pokazivac na promenljivi podatak
	pppp = &x;					// Vrednost pokazivaca moze da se menja
	*pppp = 12;					// Vrednost podatka moze da se menja
	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	const int* ppnp;			// Promenljivi pokazivac na nepromenljivi podatak
	ppnp = &x;					// Vrednost pokazivaca moze da se menja
	//*ppnp = 15;				// GRESKA: Vrednost podatka ne moze da se menja
	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	int* const nppp = &x;		// Nepromenljivi pokazivac na promenljivi podatak
	//nppp = &y;				// GRESKA: Vrednost pokazivaca ne moze da se menja
	*nppp = 14;					// Vrednost podatka moze da se menja
	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	const int* const npnp = &x;	// Nepromenljivi pokazivac na nepromenljivi podatak
	//npnp = &y;				// GRESKA: Vrednost pokazivaca ne moze da se menja
	//*npnp = 15;				// GRESKA: Vrednost podatka ne moze da se menja
	printf("x = %d\n", x);
	printf("y = %d\n", y);

	return 0;
}
