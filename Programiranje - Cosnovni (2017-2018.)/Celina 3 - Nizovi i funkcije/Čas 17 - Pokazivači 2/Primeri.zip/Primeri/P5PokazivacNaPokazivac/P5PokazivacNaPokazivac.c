#include <stdio.h>
#include <stdlib.h>

int main()
{
	int x = 10;
	int* px = &x;
	int** ppx = &px;		// Pokazivac na pokazivac (dvostruki pokazivac)

	*px = 15;
	printf("Pristup podatku preko pokazivaca: %d\n", *px);
	printf("Pristup podatku preko dvostrukog pokazivaca: %d\n", **ppx);

	return 0;
}
