#include <stdio.h>
#include <stdlib.h>

int main()
{
	int i, niz[5];

	printf("Unesite 5 celobrojnih vrednosti elemenata niza:\n");
	for (i = 0; i < 5; i++)
	{
		printf("\tniz[%d] = ", i);
		scanf("%d", niz + i);			// niz + i == &niz[i]
	}

	printf("Elementi niza:");
	for (i = 0; i < 5; i++)
		printf("\t%d", *(niz + i));		// *(niz + i) == niz[i]

	return 0;
}
