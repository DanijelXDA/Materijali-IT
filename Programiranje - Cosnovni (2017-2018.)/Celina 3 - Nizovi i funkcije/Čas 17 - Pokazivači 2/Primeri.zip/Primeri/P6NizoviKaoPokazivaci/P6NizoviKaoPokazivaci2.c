#include <stdio.h>
#include <stdlib.h>

#define DUZINA 5

int main()
{
	int niz[DUZINA];
	int *pok;

	printf("Unesite %d celobrojnih vrednosti elemenata niza:\n", DUZINA);
	for (pok = niz; pok < niz + DUZINA; pok++)
	{
		printf("\tniz[%d] = ", pok - niz);
		scanf("%d", pok);
	}

	printf("Elementi niza:");
	for (pok = niz; pok < niz + DUZINA; pok++)
		printf("\t%d", *pok);

	return 0;
}
