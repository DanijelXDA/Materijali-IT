#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija proverava da li je prosledjeni znak cifra.
    Povratna vrednost je 0 ako nije, bilo koja druga vrednost ako jeste.
*/
int jeCifra(char);

int main()
{
    char znak; // lokalna promenljiva, vazi samo u okviru main funkcije!
    int brojCifara = 0;
    printf("Unesite znakove, za kraj unesite znak q: \n");
    do
    {
        fflush(stdin);
        scanf("%c", &znak);

        if(jeCifra(znak))
        {
            brojCifara++;
        }
    }
    while(znak != 'q');

    printf("\nUneli ste %d cifre.\n", brojCifara);

    return 0;
}

int jeCifra(char znak)  // promenljiva (parametar) znak vazi samo u okviru jeCifra funkcije i nije ista kao promenljiva znak u okviru main funkcije!
{
    return znak >= '0' && znak <= '9';
}
