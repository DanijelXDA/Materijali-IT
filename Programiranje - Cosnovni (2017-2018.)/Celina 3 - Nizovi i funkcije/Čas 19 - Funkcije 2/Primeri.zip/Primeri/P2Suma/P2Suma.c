#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija racuna sumu n brojeva!
    Ako se za oznaku unese:
     0 - funkcija racuna i vraca zbir svih brojeva
     1 - funkcija racuna i vraca zbir svih parnih brojeva
     2 - funkcija racuna i vraca zbir svih neparnih brojeva
*/
int suma(int, int);

/*
    Funkcija proverava da li je prosledjeni broj paran.
    Povratna vrednost je 0 ako nije, bilo koja druga vrednost ako jeste.
*/
int paran(int);

int main()
{
    int i, s, n, oznaka, brZbirova;

    printf("Unesite koliko zbirova zelite da racunate: ");
    scanf("%d", &brZbirova);

    for(i = 1; i <= brZbirova; i++)
    {
        printf("\n\nUnesite do kog broja zelite da sabirate: ");
        scanf("%d", &n);

        printf("Unesite oznaku:(0-svi, 1-paran, 2-neparan) ");
        scanf("%d", &oznaka);

        s = suma(n, oznaka);

        printf("Suma za %d i parnost %d je: %d\n", n, oznaka, s);
    }

    return 0;
}

int suma(int n, int oznaka)
{
    int i, s = 0;

    switch(oznaka)
    {
        case 0:
            for(i = 1; i <= n; i++)
                s += i;
            break;
        case 1:
            for(i = 1; i <= n; i++)
                if(paran(i))
                    s += i;
            break;
        case 2:
            for(i = 1; i <= n; i++)
                if(!paran(i))
                    s += i;
            break;
    }

    return s;
}

int paran(int broj)
{
    return broj % 2 == 0;
}
