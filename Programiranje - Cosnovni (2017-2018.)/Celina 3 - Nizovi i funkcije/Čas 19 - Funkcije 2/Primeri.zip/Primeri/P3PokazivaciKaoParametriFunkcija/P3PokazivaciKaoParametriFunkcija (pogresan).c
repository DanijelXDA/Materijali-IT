#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima
*/
void zameniVrednosti(int x, int y)
{
    int pom = x;
    x = y;
    y = pom;
}

int main()
{
	int x = 10, y = 20;

	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	zameniVrednosti(x, y);

	printf("x = %d\n", x);
	printf("y = %d\n", y);

	return 0;
}
