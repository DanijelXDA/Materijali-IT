#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima
*/
void zameniVrednosti(int* x, int* y)
{
	if (x != NULL && y != NULL)
	{
		int pom = *x;
		*x = *y;
		*y = pom;
	}
}


int main()
{
	int x = 10, y = 20;
	int* px = NULL;
	int* py = NULL;

	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	zameniVrednosti(&x, &y);

	printf("x = %d\n", x);
	printf("y = %d\n\n", y);


    px = &x;
	zameniVrednosti(px, py);

	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

    py = &y;
	zameniVrednosti(px, py);

	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	px = NULL;
	zameniVrednosti(px, py);

	printf("x = %d\n", x);
	printf("y = %d\n\n", y);

	return 0;
}
