#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija menja vrednost promenljivoj x
*/
void prenosPoVrednosti(int x)
{
    x = 6;
}

/*
    Funkcija menja vrednost promenljivoj na koju pokazuje x
*/
void prenosPoAdresi(int* x)
{
    if (x != NULL)
    {
        *x = 6;
    }
}

int main()
{
    int a = 100;
    printf("Podatak: %d\n\n", a);

    prenosPoVrednosti(a);
    printf("Podatak nakon prenosa po vrednosti: %d \n", a);

    prenosPoAdresi(&a);
    printf("Podatak nakon prenosa po adresi: %d \n", a);

    return 0;
}
