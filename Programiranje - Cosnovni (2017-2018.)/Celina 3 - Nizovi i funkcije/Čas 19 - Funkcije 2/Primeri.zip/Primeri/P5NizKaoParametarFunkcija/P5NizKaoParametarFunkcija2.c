#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi, kao i izlazni parametar u koji se smesta broj elemenata niza.
*/
void unesiNiz(int niz[], int* pokBrElem)
{
    int i;

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    do
        scanf("%d", pokBrElem);
    while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for (i = 0; i < *pokBrElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for (i = 0; i < brElem; ++i)
        printf(" %d", niz[i]);
    printf("\n");
}

int main()
{
    int brElem, niz[MAX_DUZINA];

    unesiNiz(niz, &brElem);

    ispisiElementeNiza(niz, brElem);

    return 0;
}
