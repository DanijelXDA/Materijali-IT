#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    do
        scanf("%d", &brElem);
    while (brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for (i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for (i = 0; i < brElem; ++i)
        printf(" %d", niz[i]);
    printf("\n");
}

int main()
{
    int brElem, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);

    ispisiElementeNiza(niz, brElem);

    return 0;
}
