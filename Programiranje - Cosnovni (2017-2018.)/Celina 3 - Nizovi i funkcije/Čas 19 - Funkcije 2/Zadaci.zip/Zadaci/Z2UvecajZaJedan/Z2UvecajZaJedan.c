#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija koja uvecava ulazni celobrojni podatak za jedan.
    Sadrzi jedan ulazno-izlazni parametar u koji se smesta broj za jedan veci od ulaznog broja.
*/
void uvecajZaJedan(int* broj)
{
    (*broj)++;  // moze i  (*broj) += 1;  ili  (*broj) = (*broj) + 1;
}

int main()
{
    int i, x = 5;

    printf("Promenljiva x pre povecanja 10 puta ima vrednost: %d\n", x);

    for(i = 0; i < 10; i++)
        uvecajZaJedan(&x);

    printf("\nPromenljiva x sada ima vrednost: %d\n", x);

    return 0;
}
