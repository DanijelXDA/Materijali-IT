#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija koja omogucava unos celog broja (brojilac) od strane korisnika.
    U povratnu vrednost se smesta ucitani ceo broj.
*/
int unesiBrojilac()
{
	int brojilac = 0;

	printf("Unesite brojilac: ");
	scanf("%d", &brojilac);

	return brojilac;
}

/*
    Funkcija koja omogucava unos celog broja (imenilac) od strane korisnika.
    U povratnu vrednost se smesta ucitani ceo broj.
*/
int unesiImenilac()
{
	int imenilac = 0;

	printf("Unesite imenilac: ");
	do
		scanf("%d", &imenilac);
	while (imenilac == 0);

	return imenilac;
}

/*
	Funkcija koja vraca najmanji zajednicki delilac (NZD) za prosledjene brojeve x i y.
*/
int pronadjiNZD(int x, int y)
{
    int pom = 0;

    while(y != 0)
    {
        pom = x % y;
        x = y;
        y = pom;
    }

    return x;
}

/*
	Funkcija koja skracuje razlomak za prosledjeni brojilac i imenilac.
	Sadrzi dva ulazno-izlazna parametra, prvi za brojilac a drugi za imenilac razlomka koji se skracuje.
*/
void skratiRazlomak(int* brojilac, int* imenilac)
{
    int nzd;

	if (brojilac != NULL && imenilac != NULL)
    {
        nzd = pronadjiNZD(*brojilac, *imenilac);

        *brojilac /= nzd;
        *imenilac /= nzd;
    }
}

int main()
{
    int brojilac, imenilac;

	brojilac = unesiBrojilac();
	imenilac = unesiImenilac();

	skratiRazlomak(&brojilac, &imenilac);

	printf("\nNakon skracivanja uneti razlomak je %d/%d\n", brojilac, imenilac);

	return 0;
}
