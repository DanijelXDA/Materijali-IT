#include <stdio.h>
#include <stdlib.h>

/*
    Funkcija koja omogucava unos realnog broja od strane korisnika.
    Sadrzi jedan izlazni parametar u koji se smesta ucitani realni broj.
*/
void unesiRealanBroj(float* r)
{
    if (r != NULL)
    {
        printf("Unesite realan broj: ");
        scanf("%f", r);
    }
}

int main()
{
    float x, y, z;

    unesiRealanBroj(&x);
    unesiRealanBroj(&y);
    unesiRealanBroj(&z);

    printf("\nResenje jednacine je %.2f\n", x + 2 * y - 3 * z);

    return 0;
}
