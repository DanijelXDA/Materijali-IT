#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi, kao i izlazni parametar u koji se smesta broj elemenata niza.
*/
void unesiNiz(int niz[], int* pokBrElem)
{
    int i;

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    do
        scanf("%d", pokBrElem);
    while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for (i = 0; i < *pokBrElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }
}

/*
    Funkcija pronalazi indeks elementa sa najvecom vrednoscu.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
    Povratna vrednost predstavlja pronadjeni indeks.
*/
int pronadjiNajveciElementNiza(int niz[], int brElem)
{
    int i, maxInd = 0;

    for (i = 1; i < brElem; ++i)
        if (niz[i] > niz[maxInd])
            maxInd = i;

    return maxInd;
}

int main()
{
    int brElem, niz[MAX_DUZINA], maxInd;

    unesiNiz(niz, &brElem);

    maxInd = pronadjiNajveciElementNiza(niz, brElem);

    printf("\nNajveci element niza ima vrednost %d i nalazi se na indeksu %d.\n", niz[maxInd], maxInd);

    return 0;
}
