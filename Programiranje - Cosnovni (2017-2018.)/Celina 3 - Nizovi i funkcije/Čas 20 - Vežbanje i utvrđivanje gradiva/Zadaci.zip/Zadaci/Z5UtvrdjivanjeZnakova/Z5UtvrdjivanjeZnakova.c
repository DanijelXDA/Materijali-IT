#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata niza.
    Ima parametar za maksimalan broj elemenata niza.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiBrojElemenataNiza(int maxBrElem)
{
    int brElem;

    do
        scanf("%d", &brElem);
    while (brElem < 1 || brElem > maxBrElem);

    return brElem;
}

/*
    Funkcija omogucava unos vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void unesiElementeNiza(int niz[], int brElem)
{
    int i;

    for (i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }
}

/*
    Funkcija utvrdjuje znak elementa prosledjenog niza sa prosledjenim indeksom,
    i ukoliko je pozitivan broj menja mu vrednost na 1, a ukoliko je negativan broj menja mu vrednost na -1.
*/
void utvrdiZnak(int niz[], int indeks)
{
    if(niz[indeks] > 0)
        niz[indeks] = 1;
    else if(niz[indeks] < 0)
        niz[indeks] = -1;
}

/*
    Funkcija vrsi izmenu elemenata prosledjenog niza prosledjene duzine u zavisnosti od njihovog znaka
    (pozitivne elemente menja brojem 1, a negativne brojem -1).
*/
void preraspodeli(int niz[], int brElem)
{
    int i;

	for (i = 0; i < brElem; ++i)
        utvrdiZnak(niz, i);

}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for (i = 0; i < brElem; ++i)
        printf(" %d", niz[i]);
    printf("\n");
}

int main()
{
	int brElem, niz[MAX_DUZINA];

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    brElem = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    unesiElementeNiza(niz, brElem);

    preraspodeli(niz, brElem);
	printf("\nPreraspodela uspesno obavljena!\n");

	ispisiElementeNiza(niz, brElem);

	return 0;
}
