#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata niza.
    Ima parametar za maksimalan broj elemenata niza.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiBrojElemenataNiza(int maxBrElem)
{
    int brElem;

    do
        scanf("%d", &brElem);
    while (brElem < 1 || brElem > maxBrElem);

    return brElem;
}

/*
    Funkcija omogucava unos vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void unesiElementeNiza(int* niz, int brElem)
{
    int i;

    for (i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", niz + i);
    }
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
	if (x != NULL && y != NULL)
	{
		int pom = *x;
		*x = *y;
		*y = pom;
	}
}

/*
    Funkcija vrsi obrtanje elemenata prosledjenog niza prosledjene duzine.
*/
void obrniElementeNiza(int* niz, int brElem)
{
    int i;

    for(i = 0; i < brElem / 2; ++i)
        zameniVrednosti(niz + i, niz + brElem - i - 1);  // ili zameniVrednosti(&niz[i], &niz[brElem - i - 1]);
}

/*
    Funkcija pronalazi indeks trazenog elementa u prosledjenom nizu prosledjene duzine.
    Ima parametar za vrednost cija se pozicija trazi, parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
    Povratna vrednost predstavlja indeks trazenog elementa, odnosno -1 ukoliko se trazena vrednost ne nalazi u prosledjenom nizu.
*/
int pronadjiX(int x, int *niz, int brElem)
{
    int i;

    for(i = 0; i < brElem; ++i)
        if (*(niz + i) == x)
            return i;

    return -1;
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int* niz, int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for (i = 0; i < brElem; ++i)
        printf(" %d", *(niz + i));
    printf("\n");
}

int main()
{
	int brElem, x, index, niz[MAX_DUZINA];

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    brElem = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    unesiElementeNiza(niz, brElem);

	ispisiElementeNiza(niz, brElem);

	printf("\nKoji element zelite da pronadjete u nizu: ");
    scanf("%d", &x);

    index = pronadjiX(x, niz, brElem);
    if(index != -1)
        printf("\nBroj %d se nalazi na poziciji %d.\n", *(niz + index), index);
    else
        printf("\nBroj %d se ne nalazi u nizu.\n", x);

    return 0;
}
