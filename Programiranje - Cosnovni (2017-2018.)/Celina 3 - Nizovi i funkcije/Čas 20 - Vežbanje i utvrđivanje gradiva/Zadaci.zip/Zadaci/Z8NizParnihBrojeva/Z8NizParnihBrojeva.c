#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata niza.
    Ima parametar za maksimalan broj elemenata niza.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiBrojElemenataNiza(int maxBrElem)
{
    int brElem;

    do
        scanf("%d", &brElem);
    while (brElem < 1 || brElem > maxBrElem);

    return brElem;
}

/*
    Funkcija omogucava unos vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void unesiElementeNiza(int niz[], int brElem)
{
    int i;

    for (i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }
}

/*
	Funkcija koja vraca da li je prosledjeni broj x paran.
	Povratna vrednost je 0 ukoliko je prosledjeni broj paran, odnosno bilo koja druga vrednost ukoliko nije.
*/
int paran(int x)
{
    return x % 2 == 0;
}

/*
    Funkcija popunjava prosledjeni niz noviNiz parnim elementima prosledjenog niza polazniNiz.
    Ima parametar za prenos niza polazniNiz po adresi, parametar za broj elemenata prosledjenog niza polazniNiz,
    parametar za prenos niza noviNiz po adresi, kao i ulazno-izlazni parametar za broj elemenata niza noviNiz.
*/
void formirajNizParnih(int polazniNiz[], int brElemPolazniNiz, int noviNiz[], int* brElemNoviNiz)
{
    int i;

    for(i = 0; i < brElemPolazniNiz; i++)
        if(paran(polazniNiz[i]))
            noviNiz[(*brElemNoviNiz)++] = polazniNiz[i];
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for (i = 0; i < brElem; ++i)
        printf(" %d", niz[i]);
    printf("\n");
}

int main()
{
    int brElem, brElemNovog, niz[MAX_DUZINA], noviNiz[MAX_DUZINA];

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    brElem = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    unesiElementeNiza(niz, brElem);

    brElemNovog = 0;
    formirajNizParnih(niz, brElem, noviNiz, &brElemNovog);
    printf("\nNiz parnih brojeva uspesno formiran!\n");

    ispisiElementeNiza(noviNiz, brElemNovog);

    return 0;
}
