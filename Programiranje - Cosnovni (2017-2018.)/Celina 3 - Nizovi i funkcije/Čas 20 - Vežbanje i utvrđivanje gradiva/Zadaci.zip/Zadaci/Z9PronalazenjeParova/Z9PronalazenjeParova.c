#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi, kao i izlazni parametar u koji se smesta broj elemenata niza.
*/
void unesiNiz(int niz[], int* pokBrElem)
{
    int i;

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    do
        scanf("%d", pokBrElem);
    while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for (i = 0; i < *pokBrElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }
}

/*
    Funkcija ispisuje sve parove (koje cine elementi prosledjenog niza) cija se suma vec nalazi kao element u prosledjenom nizu.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void pronadjiParove(int niz[], int brElem)
{
    int i, j, k, brojParova = 0;

    for (i = 0; i < brElem - 1; i++)
    {
        for (j = i + 1 ; j < brElem ; j++)
        {
           for (k = 0; k < brElem; k++)
           {
              if (niz[i] + niz[j] == niz[k])
              {
                 printf("%d, %d \n", niz[i], niz[j]);
                 brojParova++;
              }
           }
        }
    }

    if (brojParova == 0)
        printf("Ne postoje takvi parovi!\n");
}

int main()
{
	int brElem, niz[MAX_DUZINA];

	unesiNiz(niz, &brElem);

	printf("\n");
	pronadjiParove(niz, brElem);

	return 0;
}
