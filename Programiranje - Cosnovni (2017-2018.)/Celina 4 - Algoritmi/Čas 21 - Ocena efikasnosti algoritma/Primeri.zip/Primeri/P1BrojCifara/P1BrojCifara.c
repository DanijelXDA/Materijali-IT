#include <stdio.h>
#include <stdlib.h>

int brojCifara(int x)
{
    int rez = 0;

    do
    {
        rez++;
        x /= 10;
    }
    while (x != 0);

    return rez;
}

int main()
{
    int n, m, brCifN, brCifM;

    printf("Unesite brojeve n i m: ");
    scanf("%d %d", &n, &m);

    brCifN = brojCifara(n);
    brCifM = brojCifara(m);

    if (brCifN > brCifM)
        printf("\nBroj cifara broja %d je veci od broja cifara broja %d\n", n, m);
    else if (brCifN < brCifM)
        printf("\nBroj cifara broja %d je veci od broja cifara broja %d\n", m, n);
    else
        printf("\nBroj cifara broja %d je jednak broju cifara broja %d\n", n, m);

    return 0;
}
