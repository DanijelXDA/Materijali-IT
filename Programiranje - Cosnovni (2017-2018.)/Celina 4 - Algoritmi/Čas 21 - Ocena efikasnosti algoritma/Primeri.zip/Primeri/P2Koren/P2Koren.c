#include <stdio.h>
#include <stdlib.h>

float koren(float x)
{
    float levi, desni, sredina;

    levi = 1;
    desni = x;
    sredina = (levi + desni) / 2;

    while (sredina * sredina != x && desni - levi > 0.001)
    {
        if (sredina * sredina < x)
            levi = sredina;
        else
            desni = sredina;

        sredina = (levi + desni) / 2;
    }

    return sredina;
}

int main()
{
    float x;

    printf("Unesite broj veci od 1 za koji trazite koren: ");
    scanf("%f", &x);

    printf("\nKoren broja %.2f je: %.2f\n", x, koren(x));

    return 0;
}
