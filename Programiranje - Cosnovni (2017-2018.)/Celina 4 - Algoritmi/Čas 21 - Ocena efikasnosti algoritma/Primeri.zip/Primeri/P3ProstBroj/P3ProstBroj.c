#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int prost(int x)
{
    int i, granica;

    i = 2;
    granica = (int) sqrt(x);

    while(x % i != 0 && i <= granica)
        i++;

    return i > granica;
}

int main()
{
    int x;

    printf("Unesite broj: ");
    scanf("%d", &x);

    if (prost(x))
        printf("\nBroj %d je prost.\n", x);
    else
        printf("\nBroj %d nije prost.\n", x);

    return 0;
}
