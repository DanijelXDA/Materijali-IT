#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAX_DUZINA 20

void unesiNiz(int niz[], int* brEl)
{
    int i;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    scanf("%d", brEl);

    for(i = 0; i < *brEl; i++)
    {
        printf("Niz[%d] = ", i);
        scanf("%d", &niz[i]);
    }
}

int prebrojParove(int niz[], int brEl)
{
    int i, brojac = 0;

    for(i = 0; i < brEl - 1; i++)
    {
        if (abs(niz[i] % 10) == abs(niz[i + 1] % 10))  // abs zbog negativnih brojeva (npr. -6 treba da gleda samo cifru, ne i znak)
        {
            brojac++;
        }
    }

    return brojac;
}

int main()
{
    int n, niz[MAX_DUZINA];

    unesiNiz(niz, &n);

    printf("\nBroj trazenih parova je: %d\n", prebrojParove(niz, n));

    return 0;
}
