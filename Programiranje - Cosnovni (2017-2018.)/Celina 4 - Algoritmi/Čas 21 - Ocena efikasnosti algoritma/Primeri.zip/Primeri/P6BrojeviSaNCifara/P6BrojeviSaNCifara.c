#include <stdio.h>
#include <stdlib.h>

int zbirCifara(int x)
{
    int rez = 0;

    while(x != 0)
    {
        rez += x % 10;
        x /= 10;
    }

    return rez;
}

int prebrojBrojeve(int brCifara, int zeljeniZbirCifara)
{
    int minN, maxN, brojac, broj;

    minN = pow(10, brCifara - 1);
    maxN = pow(10, brCifara) - 1;
    brojac = 0;

    for(broj = minN; broj <= maxN; broj++)
    {
        if(zbirCifara(broj) == zeljeniZbirCifara)
        {
            brojac++;
        }
    }

    return brojac;
}

int main()
{
    int n, k;

    printf("Unesite broj cifara: ");
    scanf("%d", &n);
    printf("\nUnesite zeljeni zbir cifara: ");
    scanf("%d", &k);

    printf("\nBroj brojeva sa %d cifara i zbirom cifara %d je %d\n", n, k, prebrojBrojeve(n, k));

    return 0;
}
