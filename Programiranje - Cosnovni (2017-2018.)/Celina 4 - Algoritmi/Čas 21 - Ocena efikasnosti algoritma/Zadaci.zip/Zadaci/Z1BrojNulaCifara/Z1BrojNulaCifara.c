#include <stdio.h>
#include <stdlib.h>

int brojNulaCifara(int broj)
{
    int rez = 0;

    do
    {
        if(broj % 10 == 0)
            rez++;

        broj /= 10;
    }
    while (broj != 0);

    return rez;
}

int main()
{
    int n, rez;

    printf("Unesite broj n: ");
    scanf("%d", &n);

    rez = brojNulaCifara(n);

    printf("\nBroj nula cifara broja %d je %d.\n", n, rez);

    return 0;
}
