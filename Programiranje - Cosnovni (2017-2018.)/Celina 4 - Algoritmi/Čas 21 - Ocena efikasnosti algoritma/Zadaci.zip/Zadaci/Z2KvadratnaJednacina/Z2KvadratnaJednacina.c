#include <stdio.h>
#include <stdlib.h>

float vrednostJednacine(float n)
{
    return n * n - 5 * n + 2;
}

float nadjiResenjeKvadJednacine(float levi, float desni)
{
    float sredina;

    sredina = (levi + desni) / 2;
    while(vrednostJednacine(sredina) != 0 && desni - levi > 0.001)
    {
        if(vrednostJednacine(sredina) < 0)
            levi = sredina;
        else
            desni = sredina;

        sredina = (levi + desni) / 2;
    }

    return sredina;
}

int main()
{
    float rez;

    rez = nadjiResenjeKvadJednacine(1, 10);

    printf("Resenje kvadratne jednacine je: %.2f\n", rez);

    return 0;
}
