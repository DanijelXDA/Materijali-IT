#include <stdio.h>
#include <stdlib.h>

float koren(float n)
{
    float x;

    x = 1;
    while((x + 0.01) * (x + 0.01) < n)
    {
        x += 0.01;
    }

    return x;
}

int main()
{
    float n, rez;

    printf("Unesite broj veci od 1 za koji trazite koren: ");
    scanf("%f", &n);

    rez = koren(n);

    printf("\nKoren broja %.2f je: %.2f\n", n, rez);

    return 0;
}
