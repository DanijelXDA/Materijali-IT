#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

int unesiOcene(int niz[])
{
    int i, brElem;

    printf("Unesite broj ocena koji cete unositi [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while (brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite ocene:\n");
    for (i = 0; i < brElem; ++i)
    {
        printf("\tocena[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

int prebrojOcenu(int niz[], int brElem, int ocena)
{
    int i, brojac;

    brojac = 0;
    for(i = 0; i < brElem; i++)
    {
        if(niz[i] == ocena)
        {
            brojac++;
        }
    }

    return brojac;
}

int main()
{
    int n, niz[MAX_DUZINA], brojOcena, brojMaxOcena, maxOcena, i;

    n = unesiOcene(niz);

    maxOcena = 1;
    brojMaxOcena = 0;  // ne znamo koliko ih ima, moramo prebrojati
    for(i = 1; i < n; i++)
    {
        brojOcena = prebrojOcenu(niz, n, i);

        if(brojOcena > brojMaxOcena)
        {
            brojMaxOcena = brojOcena;
            maxOcena = i;
        }
    }

    printf("\nNajvise se ponavlja ocena %d i to %d puta.\n", maxOcena, brojMaxOcena);

    return 0;
}
