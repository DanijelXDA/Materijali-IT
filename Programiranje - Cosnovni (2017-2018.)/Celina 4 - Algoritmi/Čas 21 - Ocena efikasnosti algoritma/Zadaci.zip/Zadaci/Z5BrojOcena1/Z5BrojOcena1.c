#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

int unesiOcene(int niz[])
{
    int i, brElem;

    printf("Unesite broj ocena koji cete unositi [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while (brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite ocene:\n");
    for (i = 0; i < brElem; ++i)
    {
        printf("\tocena[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}


int main()
{
    int n, niz[MAX_DUZINA], brojOcena, brojMaxOcena, maxOcena, i;
    int brojac[5] = {0, 0, 0, 0, 0};

    n = unesiOcene(niz);

    for(i = 0; i < n; i++)
    {
        brojac[niz[i] - 1]++;
    }

    maxOcena = 1;
    brojMaxOcena = brojac[0];
    for(i = 1; i < 5; i++)
    {
        if (brojac[i] > brojMaxOcena)
        {
            brojMaxOcena = brojac[i];
            maxOcena = i + 1;
        }
    }

    printf("\nNajvise se ponavlja ocena %d i to %d puta.\n", maxOcena, brojMaxOcena);

    return 0;
}
