#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while (brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for (i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

void ispisiPodnizSaNajvecimZbirom(int a[], int n)
{
    int i, j, zbir, maxZbir, p, k;
    int d[MAX_DUZINA];

    p = 0;
    k = 0;
    j = 0;
    maxZbir = a[0];
    d[0] = 0;
    for (i = 0; i < n; i++)
    {
        d[i + 1] = d[i] + a[i];

        if (maxZbir < d[i + 1])
        {
            maxZbir = d[i + 1];
            p = j;
            k = i;
        }

        if (d[i + 1] < 0)
        {
            d[i + 1] = 0;
            j = i + 1;
        }
    }

    printf("\nNajveci zbir je: %d i nalazi se u intervalu izmedju elemenata %d i %d.", maxZbir, p, k);
    printf("\nU pitanju je podniz: ");
    for(i = p; i <= k; i++)
        printf("%d ", a[i]);
    printf("\n");
}

int main()
{
    int i, n, a[MAX_DUZINA];

    n = unesiNiz(a);

    ispisiPodnizSaNajvecimZbirom(a, n);

    return 0;
}
