#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for(i = 0; i < brElem; ++i)
    {
        printf(" %d", niz[i]);
    }
    printf("\n");
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
    if(x != NULL && y != NULL)
    {
        int pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenog niza prosledjene duzine
    u rastucem (neopadajucem) redosledu uz pomoc optimizovanog Bubble Sort algoritma.
*/
void optimizovaniBubbleSort(int niz[], int brElem)
{
    int i, n = brElem;
    int biloZamene;

    do
    {
        biloZamene = 0;

        for(i = 0; i < n - 1; ++i)
        {
            if(niz[i] > niz[i + 1])  // > za neopadajuci, a < za nerastuci sort
            {
                zameniVrednosti(&niz[i], &niz[i + 1]);
                biloZamene = 1;
            }
        }
        n--;
    }
    while(biloZamene == 1); //zavrsava sa sortiranjem cim se desi prolaz u kom nije bilo zamene
}

int main()
{
    int brElem, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);

    ispisiElementeNiza(niz, brElem);

    optimizovaniBubbleSort(niz, brElem);
    printf("\nNiz je sortiran u rastucem redosledu!\n");

    ispisiElementeNiza(niz, brElem);

    return 0;
}
