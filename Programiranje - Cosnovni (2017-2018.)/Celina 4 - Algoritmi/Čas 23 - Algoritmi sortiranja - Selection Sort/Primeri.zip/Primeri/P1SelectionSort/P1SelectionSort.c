#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for(i = 0; i < brElem; ++i)
    {
        printf(" %d", niz[i]);
    }
    printf("\n");
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
    if(x != NULL && y != NULL)
    {
        int pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenog niza prosledjene duzine u rastucem (neopadajucem) redosledu uz pomoc Selection Sort algoritma.
*/
void selectionSort(int niz[], int brElem)
{
    int i, j, minI;

    for(i = 0; i < brElem - 1; ++i)
    {
        minI = i;
        for(j = i + 1; j < brElem; ++j)
        {
            if(niz[j] < niz[minI])  // < za neopadajuci, a > za nerastuci sort
            {
                minI = j;
            }
        }
        if(i != minI)
        {
            zameniVrednosti(&niz[i], &niz[minI]);
        }
    }
}

/*
    Funkcija pronalazi i vraca vrednost prvog pozitivnog clana u prosledjenom nizu prosledjene duzine.
    Ukoliko u njemu nema clanova sa pozitivnom vrednoscu, funkcija vraca 0.
*/
int prviPozitivan(int niz[], int brElem)
{
    int i = 0, nadjen = 0;

    while(!nadjen && i < brElem)
    {
        if(niz[i] > 0)
        {
            nadjen = 1;
        }
        else
        {
            i++;
        }
    }

    if(nadjen)
    {
        return niz[i];
    }
    else
    {
        return 0;
    }
}

int main()
{
    int brElem, prviPoz, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);

    ispisiElementeNiza(niz, brElem);

    prviPoz = prviPozitivan(niz, brElem);
    if(prviPoz)
    {
        printf("\nPrvi pozitivan clan niza je %d.\n", prviPoz);
    }
    else
    {
        printf("\nU nizu nema pozitivnih clanova.\n");
    }

    selectionSort(niz, brElem);
    printf("\nNiz je sortiran u rastucem redosledu!\n");

    ispisiElementeNiza(niz, brElem);

    prviPoz = prviPozitivan(niz, brElem);
    if(prviPoz)
    {
        printf("\nPrvi pozitivan clan niza je %d.\n", prviPoz);
    }
    else
    {
        printf("\nU nizu nema pozitivnih clanova.\n");
    }

    return 0;
}
