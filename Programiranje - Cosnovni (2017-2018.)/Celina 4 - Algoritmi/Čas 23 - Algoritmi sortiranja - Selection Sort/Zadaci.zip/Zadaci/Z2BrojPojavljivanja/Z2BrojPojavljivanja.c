#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
    if(x != NULL && y != NULL)
    {
        int pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenog niza prosledjene duzine u rastucem (neopadajucem) redosledu uz pomoc Selection Sort algoritma.
*/
void selectionSort(int niz[], int brElem)
{
    int i, j, minI;

    for(i = 0; i < brElem - 1; ++i)
    {
        minI = i;
        for(j = i + 1; j < brElem; ++j)
        {
            if(niz[j] < niz[minI])  // < za neopadajuci, a > za nerastuci sort
            {
                minI = j;
            }
        }
        if(i != minI)
        {
            zameniVrednosti(&niz[i], &niz[minI]);
        }
    }
}


/*
    Funkcija omogucava ispis broja pojavljivanja vrednosti elemenata celobrojnog niza
    (neophodno je da su vrednosti prethodno sortirane u neopadajucem ili nerastucem redosledu).
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiBrojPojavljivanja(int niz[], int brElem)
{
    int i;

    printf("\n%3d *", niz[0]);
	for (i = 1; i < brElem; ++i)
	{
		if(niz[i] > niz[i - 1])
        {
            printf("\n%3d ", niz[i]);
        }
        printf("*");

    }
    printf("\n");
}


int main()
{
    int brElem, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);

    selectionSort(niz, brElem);
    printf("\nNiz je sortiran u rastucem redosledu!\n");

    ispisiBrojPojavljivanja(niz, brElem);

    return 0;
}
