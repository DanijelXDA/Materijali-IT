#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja tacaka, kao i vrednosti tacaka (datih u vidu nizova njihovih x i y koordinata).
    Ima ulazno-izlazne parametre za prenos nizova po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata nizova.
*/
int unesiTacke(int x[], int y[])
{
    int i, brElem;

    printf("Unesite broj tacaka [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite tacke:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\n\t%d. tacka:\n\t\tx = ", i + 1);
        scanf("%d", &x[i]);

        printf("\t\ty = ");
        scanf("%d", &y[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis prosledjenih tacaka (datih u vidu nizova njihovih x i y koordinata).
    Ima parametre za prenos nizova po adresi, i parametar za broj elemenata prosledjenih nizova.
*/
void ispisiTacke(int x[], int y[], int brElem)
{
    int i;

    printf("\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("(%d, %d) ", x[i], y[i]);
    }
    printf("\n");
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
    if(x != NULL && y != NULL)
    {
        int pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenih tacaka (datih u vidu nizova njihovih x i y koordinata)
    prosledjene duzine u rastucem (neopadajucem) redosledu po x koordinati uz pomoc Selection Sort algoritma.
*/
void selectionSortPoXu(int x[], int y[], int brElem)
{
    int i, j, minI;

    for(i = 0; i < brElem - 1; ++i)
    {
        minI = i;
        for(j = i + 1; j < brElem; ++j)
        {
            if(x[j] < x[minI])  // < za neopadajuci, a > za nerastuci sort
            {
                minI = j;
            }
        }
        if(i != minI)
        {
            zameniVrednosti(&x[i], &x[minI]);
            zameniVrednosti(&y[i], &y[minI]);
        }
    }
}

int main()
{
    int brElem, x[MAX_DUZINA], y[MAX_DUZINA];

    brElem = unesiTacke(x, y);

    ispisiTacke(x, y, brElem);

    selectionSortPoXu(x, y, brElem);
    printf("\nTacke su sortirane u rastucem redosledu po x koordinati!\n");

    ispisiTacke(x, y, brElem);

    return 0;
}
