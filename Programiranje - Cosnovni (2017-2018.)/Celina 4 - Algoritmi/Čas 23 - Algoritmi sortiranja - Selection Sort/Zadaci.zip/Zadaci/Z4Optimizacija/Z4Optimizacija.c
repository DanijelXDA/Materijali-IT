#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    for(i = 0; i < brElem; ++i)
    {
        printf(" %d", niz[i]);
        if(i != brElem - 1)
            printf(",");
        else
            printf(".");
    }
    printf("\n");
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
    if(x != NULL && y != NULL)
    {
        int pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenog niza prosledjene duzine
    u rastucem (neopadajucem) redosledu uz pomoc optimizovanog Selection Sort algoritma.
*/
void optimizovaniSelectionSort(int niz[], int brElem)
{
    int i, j, minI, maxI;

    for(i = 0; i < brElem / 2; ++i)
    {
        minI = i;
        maxI = i;

        // trazimo najmanji i najveci element od i-tog do (brElem - i - 1)-og
        for(j = i + 1; j < brElem - i; j++)
        {
            if(niz[j] < niz[minI])   // < za neopadajuci, a > za nerastuci sort
                minI = j;
            else if(niz[j] > niz[maxI])   // > za neopadajuci, a < za nerastuci sort
                maxI = j;
        }
        if(minI != i)
        {
            zameniVrednosti(&niz[i], &niz[minI]);

            // ako pomeramo najveci element
            if(maxI == i)
                maxI = minI;
        }
        if(maxI != brElem - i - 1)
        {
            zameniVrednosti(&niz[brElem - i - 1], &niz[maxI]);
        }
    }
}

int main()
{
    int brElem, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);

    optimizovaniSelectionSort(niz, brElem);

    printf("\nSortiran niz izgleda ovako: ");
    ispisiElementeNiza(niz, brElem);


    return 0;
}
