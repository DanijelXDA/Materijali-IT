/*
 * Program koji demonstrira koriscenje InsertionSort algoritma
 * Program koristi optimizovanu verziju algoritma
 */

#include <stdio.h>

#define MAX_DUZINA 20

// Funkcija koja omogucava unos niza od strane korisnika
void UnesiNiz(int niz[], int* pokBrElem)
{
    int i;

	printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
	do
		scanf("%d", pokBrElem);
	while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

	printf("Unesite celobrojne vrednosti elemenata niza:\n");
	for (i = 0; i < *pokBrElem; ++i)
	{
		printf("\tniz[%d] = ", i);
		scanf("%d", &niz[i]);
	}
}

// Funkcija koja vrsi sortiranje prosledjenog niza prosledjene duzine uz pomoc optimizovanog insertion sort algoritma
void InsertionSort(int niz[], int brElem)
{
   int i, j, p;
   j = 0;
   for (i = 1; i < brElem; i++)
   {
       if(niz[j] > niz[i]){
            j = i;
       }
   }
   if(j != 0){
        p = niz[j];
        niz[j] = niz[0];
        niz[0] = p;
   }
   for(i = 2; i < brElem; i++){
        j = i-1;
        p = niz[i];
        while(p<niz[j]){
            niz[j+1] = niz[j];
            j = j-1;
        }
        niz[j+1] = p;
   }
}

// Funkcija koja ispisuje elemente prosledjenog niza prosledjene duzine
void IspisiNiz(int niz[], int brElem)
{
    int i;

	for (i = 0; i < brElem; ++i)
	{
		printf(" %d", niz[i]);
    }
    printf("\n");
}

int main()
{
	int brElem, niz[MAX_DUZINA];

	UnesiNiz(niz, &brElem);

	InsertionSort(niz, brElem);
    printf("Sortiran niz izgleda ovako!\n");

	IspisiNiz(niz, brElem);


	return 0;
}
