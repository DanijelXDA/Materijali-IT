/*
 * Program koji demonstrira koriscenje InsertionSort algoritma
 * Program odredjuje mesto najvece razlike izmedju dva elementa sortiranog niza
 */

#include <stdio.h>

#define MAX_DUZINA 20

// Funkcija koja omogucava unos niza od strane korisnika
void UnesiNiz(int niz[], int* pokBrElem)
{
    int i;

	printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
	do
		scanf("%d", pokBrElem);
	while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

	printf("Unesite celobrojne vrednosti elemenata niza:\n");
	for (i = 0; i < *pokBrElem; ++i)
	{
		printf("\tniz[%d] = ", i);
		scanf("%d", &niz[i]);
	}
}

// Funkcija koja vrsi sortiranje prosledjenog niza prosledjene duzine uz pomoc insertion sort algoritma
void InsertionSort(int niz[], int brElem)
{
   int i, trenutni, j;
   for (i = 1; i < brElem; i++)
   {
	   trenutni = niz[i];
	   j = i-1;

	   while (j >= 0 && niz[j] < trenutni)
	   {
		   niz[j+1] = niz[j];
		   j = j-1;
	   }
	   niz[j+1] = trenutni;

   }
}

// Funkcija koja ispisuje elemente prosledjenog niza prosledjene duzine
void IspisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("Clanovi niza su:");
	for (i = 0; i < brElem; ++i)
	{
		printf(" %d", niz[i]);
    }
    printf("\n");
}

// Funkcija koja vraca poziciju najvece razlike susednih elemenata u sortiranom nizu
int nadjiGranicu(int niz[], int brElem)
{
   int i, gr;
   gr = 0;
   for(i=1; i<brElem; i++)
   {
     if (niz[gr]-niz[gr+1]<=niz[i]-niz[i+1])
        {
            gr = i;
        }
   }
   return gr+1;
}

int main()
{
	int brElem, niz[MAX_DUZINA], rez;

	UnesiNiz(niz, &brElem);

	IspisiElementeNiza(niz, brElem);

	InsertionSort(niz, brElem);

	IspisiElementeNiza(niz, brElem);

    rez = nadjiGranicu(niz, brElem);

    printf("Dalje je proslo %d takmicara", rez);

	return 0;
}
