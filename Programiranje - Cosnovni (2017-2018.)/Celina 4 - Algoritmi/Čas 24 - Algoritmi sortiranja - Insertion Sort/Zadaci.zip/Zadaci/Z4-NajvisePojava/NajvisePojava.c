/*
 * Program koji demonstrira koriscenje InsertionSort algoritma
 * Program odredjuje element niza koji se najvise puta ponavlja u nizu
 */

#include <stdio.h>

#define MAX_DUZINA 20

// Funkcija koja omogucava unos niza od strane korisnika
void UnesiNiz(int niz[], int* pokBrElem)
{
    int i;

	printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
	do
		scanf("%d", pokBrElem);
	while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

	printf("Unesite celobrojne vrednosti elemenata niza:\n");
	for (i = 0; i < *pokBrElem; ++i)
	{
		printf("\tniz[%d] = ", i);
		scanf("%d", &niz[i]);
	}
}

// Funkcija koja vrsi sortiranje prosledjenog niza prosledjene duzine uz pomoc insertion sort algoritma
void InsertionSort(int niz[], int brElem)
{
   int i, trenutni, j;
   for (i = 1; i < brElem; i++)
   {
	   trenutni = niz[i];
	   j = i-1;

	   while (j >= 0 && niz[j] < trenutni)
	   {
		   niz[j+1] = niz[j];
		   j = j-1;
	   }
	   niz[j+1] = trenutni;

   }
}

// Funkcija pronalazi i ispisuje broj koji se najvise puta nalazi u nizu
void NajvisePojava(int niz[], int brElem)
{
    int i, j, p, ind;
    j = 1;
    p = 1;
    ind = 0;

    for(i = 0; i < brElem-1; i++){
        if(niz[i] == niz[i+1]){
            j = j + 1;
            if(j > p){
                p = j;
                ind = i;
            }
        } else {
            j = 1;
        }
    }
    printf("Brojeva %d ima %d puta!\n", niz[ind], p);
}

int main()
{
	int brElem, niz[MAX_DUZINA];

	UnesiNiz(niz, &brElem);

	InsertionSort(niz, brElem);

    NajvisePojava(niz, brElem);

	return 0;
}
