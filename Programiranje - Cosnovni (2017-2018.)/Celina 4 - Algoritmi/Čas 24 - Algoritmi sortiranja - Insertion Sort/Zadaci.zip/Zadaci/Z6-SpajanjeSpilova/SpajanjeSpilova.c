/*
 * Program koji demonstrira koriscenje InsertionSort algoritma
 * PRogram spaja dva sortirana niza u novi sortirani niz
 */

#include <stdio.h>

#define MAX_DUZINA 20

// Funkcija koja omogucava unos niza od strane korisnika
void UnesiNiz(int niz[], int* pokBrElem)
{
    int i;

	printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
	do
		scanf("%d", pokBrElem);
	while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

	printf("Unesite celobrojne vrednosti elemenata niza:\n");
	for (i = 0; i < *pokBrElem; ++i)
	{
		printf("\tniz[%d] = ", i);
		scanf("%d", &niz[i]);
	}
}

// Funkcija koja vrsi sortiranje prosledjenog niza prosledjene duzine uz pomoc insertion sort algoritma
void InsertionSort(int niz[], int brElem)
{
   int i, trenutni, j;
   for (i = 1; i < brElem; i++)
   {
	   trenutni = niz[i];
	   j = i-1;

	   /* Pomeri elemente niza [0..i-1], koji su veci od trenutnog,
		  za jednu poziciju unapred u odnosu na trenutnu poziciju
	   */
	   while (j >= 0 && niz[j] > trenutni)
	   {
		   niz[j+1] = niz[j];
		   j = j-1;
	   }
	   niz[j+1] = trenutni;
   }
}

// Funkcija koja ispisuje elemente prosledjenog niza prosledjene duzine
void IspisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("Clanovi niza su:");
	for (i = 0; i < brElem; ++i)
	{
		printf(" %d", niz[i]);
    }
    printf("\n");
}

// Funkcija koja spaja dva sortirana spila slicica u treci sortirani spil
void spojiSlicice(int niz1[], int brElem1, int niz2[], int brElem2, int niz3[], int *brElem3)
{
    int i, j;
    *brElem3 = brElem1 + brElem2;
    i = 0;
    j = 0;
    while (i<brElem1 && j<brElem2){
        if (niz1[i]<niz2[j]){
            niz3[i+j] = niz1[i];
            i++;
        } else {
            niz3[i+j] = niz2[j];
            j++;
        }
    }
    while (i<brElem1){
            niz3[i+j] = niz1[i];
            i++;
    }
    while (j<brElem2){
            niz3[i+j] = niz2[j];
            j++;
    }
}
int main()
{
	int brElem1, niz1[MAX_DUZINA];
	int brElem2, niz2[MAX_DUZINA];
	int brElem3, niz3[2*MAX_DUZINA];

	UnesiNiz(niz1, &brElem1);

	IspisiElementeNiza(niz1, brElem1);

	UnesiNiz(niz2, &brElem2);

	IspisiElementeNiza(niz2, brElem2);

	InsertionSort(niz1, brElem1);

    spojiSlicice(niz1, brElem1, niz2, brElem2, niz3, &brElem3);

    printf("Sasine slicice nakon spajanja.");

	IspisiElementeNiza(niz3, brElem3);

	return 0;
}
