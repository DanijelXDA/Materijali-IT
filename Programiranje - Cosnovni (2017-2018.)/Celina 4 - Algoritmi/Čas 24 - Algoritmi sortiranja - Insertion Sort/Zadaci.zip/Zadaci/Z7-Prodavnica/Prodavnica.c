/*
 * Program koji demonstrira koriscenje InsertionSort algoritma
 * Program koji ispisuje redosled elemenata niya, ako se zna broj
 * vecih elemenata niza pre datog elementa
 */

#include <stdio.h>

#define MAX_DUZINA 20

// Funkcija koja omogucava unos niza od strane korisnika
void UnesiNiz(int niz[], int* pokBrElem)
{
    int i;

	printf("Unesite broj elemenata nizova [1-%d]: ", MAX_DUZINA);
	do
		scanf("%d", pokBrElem);
	while (*pokBrElem < 1 || *pokBrElem > MAX_DUZINA);

	printf("Unesite celobrojne vrednosti elemenata niza:\n");
	for (i = 0; i < *pokBrElem; ++i)
	{
		printf("\tniz[%d] = ", i);
		scanf("%d", &niz[i]);
	}
}

// Funkcija koja vrsi sortiranje prosledjenog niza prosledjene duzine uz pomoc insertion sort algoritma
void ispisiRedosled(int niz[], int brElem)
{
   int redosled[MAX_DUZINA];
   int i, trenutni, j;
   for (i = 0; i<brElem; i++){
     redosled[i] = i+1;
   }
   for (i = 1; i < brElem; i++)
   {
	   for(j=0; j<niz[i]; j++)
	   {
		   redosled[i-j] = redosled[i-j-1];
	   }
	   redosled[i-niz[i]] = i+1;
   }
   printf("Redosled kupaca je: ");
   	for (i = 0; i < brElem; ++i)
	{
		printf(" %d", redosled[i]);
    }
}

// Funkcija koja ispisuje elemente prosledjenog niza prosledjene duzine
void IspisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("Clanovi niza su:");
	for (i = 0; i < brElem; ++i)
	{
		printf(" %d", niz[i]);
    }
    printf("\n");
}

int main()
{
	int brElem, niz[MAX_DUZINA];

	UnesiNiz(niz, &brElem);

	IspisiElementeNiza(niz, brElem);

	ispisiRedosled(niz, brElem);

	return 0;
}
