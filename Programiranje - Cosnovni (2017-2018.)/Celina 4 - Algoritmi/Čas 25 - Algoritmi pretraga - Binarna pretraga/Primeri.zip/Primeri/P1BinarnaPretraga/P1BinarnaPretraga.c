#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata celobrojnog niza, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(int niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        scanf("%d", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis vrednosti elemenata celobrojnog niza.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(int niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for(i = 0; i < brElem; ++i)
    {
        printf(" %d", niz[i]);
    }
    printf("\n");
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(int* x, int* y)
{
    if(x != NULL && y != NULL)
    {
        int pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenog niza prosledjene duzine u rastucem (neopadajucem) redosledu uz pomoc Selection Sort algoritma.
*/
void selectionSort(int niz[], int brElem)
{
    int i, j, minI;

    for(i = 0; i < brElem - 1; ++i)
    {
        minI = i;
        for(j = i + 1; j < brElem; ++j)
        {
            if(niz[j] < niz[minI])  // < za neopadajuci, a > za nerastuci sort
            {
                minI = j;
            }
        }
        if(i != minI)
        {
            zameniVrednosti(&niz[i], &niz[minI]);
        }
    }
}

/*
    Funkcija koja poredi dva prosledjena cela broja i
    vraca 1 ukoliko je prvi veci od dugog,
    odnosno -1 ukoliko je drugi veci od prvog,
    odnosno 0 ukoliko su im vrednosti jednake.
*/
int proveriKriterijumPretrage(int i, int j)
{
    int rez = 1;  // ako je i > j treba da vrati 1

    if (i == j)
        rez = 0;
    else if (i < j)
        rez = -1;

    return rez;
}

/*
    Funkcija pronalazi i vraca na kom indeksu u prosledjenom
    (unapred rastuce sortiranom) nizu prosledjene duzine
    se nalazi prosledjeni element. Ukoliko se on ne nalazi u
    prosledjenom nizu, funkcija vraca -1.
*/
int binarnaPretraga(int niz[], int brElem, int element)
{
    int sredina, rez, pocetak = 0, kraj = brElem - 1;

    while (pocetak <= kraj)
    {
        sredina = (pocetak + kraj) / 2;

        rez = proveriKriterijumPretrage(element, niz[sredina]);

        // provera da li je pretraga zavrsena
        if (rez == 0)  // element je pronadjen, zavrsava se pretraga
            return sredina;
        else if (rez == 1)  // element veci od trenutnog, trazi u desnoj polovini niza
            pocetak = sredina + 1;
        else  // element manji od trenutnog, trazi u levoj polovini niza
            kraj = sredina - 1;
    }

    return -1;
}

int main()
{
    int brElem, poslednjiElem, indeksPosElem, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);
    poslednjiElem = niz[brElem - 1];

    ispisiElementeNiza(niz, brElem);

    selectionSort(niz, brElem);
    printf("\nNiz je sortiran u rastucem redosledu!\n");

    ispisiElementeNiza(niz, brElem);

    indeksPosElem = binarnaPretraga(niz, brElem, poslednjiElem);

    if(indeksPosElem < 0)
        printf("\nPoslednji uneti element ima vrednost %d, ali nije pronadjen u nizu!\n", poslednjiElem);
    else
        printf("\nPoslednji uneti element ima vrednost %d i nakon sortiranja niza nalazi se na indeksu %d.\n", poslednjiElem, indeksPosElem);

    return 0;
}
