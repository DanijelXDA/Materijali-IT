#include <stdio.h>
#include <stdlib.h>

#define MAX_DUZINA 20

/*
    Funkcija omogucava unos broja elemenata niza karaktera, kao i njihovih vrednosti.
    Ima ulazno-izlazni parametar za prenos niza po adresi.
    Povratna vrednost predstavlja ucitani broj elemenata niza.
*/
int unesiNiz(char niz[])
{
    int i, brElem;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    do
    {
        scanf("%d", &brElem);
    }
    while(brElem < 1 || brElem > MAX_DUZINA);

    printf("\nUnesite celobrojne vrednosti elemenata niza:\n");
    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%d] = ", i);
        fflush(stdin);
        scanf("%c", &niz[i]);
    }

    return brElem;
}

/*
    Funkcija omogucava ispis vrednosti elemenata niza karaktera.
    Ima parametar za prenos niza po adresi, i parametar za broj elemenata prosledjenog niza.
*/
void ispisiElementeNiza(char niz[], int brElem)
{
    int i;

    printf("\nClanovi niza su:");
    for(i = 0; i < brElem; ++i)
    {
        printf(" %c", niz[i]);
    }
    printf("\n");
}

/*
    Funkcija menja vrednosti u memoriji prosledjenim podacima.
*/
void zameniVrednosti(char* x, char* y)
{
    if(x != NULL && y != NULL)
    {
        char pom = *x;
        *x = *y;
        *y = pom;
    }
}

/*
    Funkcija vrsi sortiranje prosledjenog niza prosledjene duzine u rastucem (neopadajucem) redosledu uz pomoc Selection Sort algoritma.
*/
void selectionSort(char niz[], int brElem)
{
    int i, j, minI;

    for(i = 0; i < brElem - 1; ++i)
    {
        minI = i;
        for(j = i + 1; j < brElem; ++j)
        {
            if(niz[j] < niz[minI])  // < za neopadajuci, a > za nerastuci sort
            {
                minI = j;
            }
        }
        if(i != minI)
        {
            zameniVrednosti(&niz[i], &niz[minI]);
        }
    }
}

/*
    Funkcija koja poredi dva prosledjena karaktera i
    vraca 1 ukoliko je ASCII kod prvog veci od drugog,
    odnosno -1 ukoliko je ASCII kod drugog veci od prvog,
    odnosno 0 ukoliko su im ASCII kodovi jednaki.
*/
int proveriKriterijumPretrage(char i, char j)
{
    int rez = 1;  // ako je i > j treba da vrati 1

    if (i == j)
        rez = 0;
    else if (i < j)
        rez = -1;

    return rez;
}

/*
    Funkcija pronalazi i vraca na kom indeksu u prosledjenom
    (unapred rastuce sortiranom) nizu prosledjene duzine
    se nalazi prosledjeni element. Ukoliko se on ne nalazi u
    prosledjenom nizu, funkcija vraca -1.
*/
int binarnaPretraga(char niz[], int brElem, char element)
{
    int sredina, rez, pocetak = 0, kraj = brElem - 1;

    while (pocetak <= kraj)
    {
        sredina = (pocetak + kraj) / 2;

        rez = proveriKriterijumPretrage(element, niz[sredina]);

        // provera da li je pretraga zavrsena
        if (rez == 0)  // element je pronadjen, zavrsava se pretraga
            return sredina;
        else if (rez == 1)  // ASCII kod elementa veci od ASCII koda trenutnog, trazi u desnoj polovini niza
            pocetak = sredina + 1;
        else  // ASCII kod elementa manji od ASCII koda trenutnog, trazi u levoj polovini niza
            kraj = sredina - 1;
    }

    return -1;
}

int main()
{
    int brElem, indeksX;
    char x, niz[MAX_DUZINA];

    brElem = unesiNiz(niz);

    ispisiElementeNiza(niz, brElem);

    selectionSort(niz, brElem);
    printf("\nNiz je sortiran u rastucem redosledu!\n");

    ispisiElementeNiza(niz, brElem);

    printf("\nUnesite slovo koje trazite: x = ");
    fflush(stdin);
    scanf("%c", &x);

    indeksX = binarnaPretraga(niz, brElem, x);

    if(indeksX < 0)
        printf("\nSlovo %c nije pronadjeno u nizu!\n", x);
    else
        printf("\nSlovo %c se nalazi u nizu na indeksu %d.\n", x, indeksX);

    return 0;
}
