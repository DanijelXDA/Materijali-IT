#include "kalkulator.h"

//definicije funkcija u posebnom modulu
float racunajZbir(float a, float b)
{
	return a + b;
}

float racunajRazliku(float a, float b)
{
	return a - b;
}

float racunajProizvod(float a, float b)
{
	return a * b;
}

float racunajKolicnik(float a, float b)
{
	return a / b;
}
