#ifndef _KALKULATOR_H_  // pretprocesorske direktive za sprecavanje visestrukog prevodjenja
#define _KALKULATOR_H_

// deklaracije funkcija u datoteci zaglavlja
float racunajZbir(float a, float b);
float racunajRazliku(float a, float b);
float racunajProizvod(float a, float b);
float racunajKolicnik(float a, float b);

#endif  // _KALKULATOR_H_
