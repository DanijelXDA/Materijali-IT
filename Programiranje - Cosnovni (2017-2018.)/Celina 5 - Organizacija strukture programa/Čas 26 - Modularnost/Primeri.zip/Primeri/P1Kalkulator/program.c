/*
    Primer demonstrira implementaciju cetiri osnovne aritmeticke operacije na modularan nacin u programskom jeziku C
*/

#include <stdio.h>
#include "kalkulator.h"  // umetanje sadrzaja datoteke zaglavlja za povezivanje sa drugim modulom

int main()
{
	float a = 0.0, b = 0.0;

	printf("Unesite prvi operand: ");
	scanf("%f", &a);

	printf("Unesite drugi operand: ");
	scanf("%f", &b);

	// pozivanje funkcija definisanih u drugom modulu
	printf("%.2f + %.2f = %.2f\n", a, b, racunajZbir(a, b));
	printf("%.2f - %.2f = %.2f\n", a, b, racunajRazliku(a, b));
	printf("%.2f * %.2f = %.2f\n", a, b, racunajProizvod(a, b));
	printf("%.2f / %.2f = %.2f\n", a, b, racunajKolicnik(a, b));

	return 0;
}
