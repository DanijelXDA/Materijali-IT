#include <stdio.h>
#include <stdlib.h>

#include "niz.h"


int main()
{
    IntegerNiz v1, v2;

    printf("Unesite duzinu vektora [1-%d]: ", MAX_DUZINA);
    ui duzina = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("Unesite elemente prvog vektora:\n");
    unesiElementeNiza(v1, duzina);

    printf("Unesite elemente drugog vektora:\n");
    unesiElementeNiza(v2, duzina);

    printf("Skalarni proizvod vektora je %d.\n", racunajSkalarniProizvodNiza(v1, v2, duzina));

    printf("Cirkularni pomak vektora ulevo za 1:\n");

    pomeriCiklicnoULevoZaJedan(v1, duzina);
    ispisiElementeNiza(v1, duzina);

    printf("Cirkularni pomak vektora udesno za 1:\n");

    pomeriCiklicnoUDesnoZaJedan(v2, duzina);
    ispisiElementeNiza(v2, duzina);

    IntegerNiz niz;

    printf("Unesite duzinu vektora [1-%d]: ", MAX_DUZINA);
    ui n = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("Unesite elemente novog vektora:\n");
    unesiElementeNiza(niz, n);

    ui index = pronadjiNajmanjiElementNiza(niz, n);
    izbaciZadatElementNiza(niz, &n, niz[index]);

    printf("Izbaceni minimalni elementi vektora ulevo za 1:\n");
    ispisiElementeNiza(niz, n);

    return 0;
}
