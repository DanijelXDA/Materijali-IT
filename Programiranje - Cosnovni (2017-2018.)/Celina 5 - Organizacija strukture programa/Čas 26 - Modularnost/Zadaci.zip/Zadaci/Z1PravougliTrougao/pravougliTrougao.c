#include <math.h>

#include "pravougliTrougao.h"

double izracunajHipotenuzu(double k1, double k2)
{
	return sqrt(pow(k1, 2) + pow(k2, 2));
}

double izracunajObim(double k1, double k2)
{
	return k1 + k2 + izracunajHipotenuzu(k1, k2);
}

double izracunajPovrsinu(double k1, double k2)
{
	return (k1 * k2) / 2;
}
