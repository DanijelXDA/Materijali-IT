#ifndef _PRAVOUGLI_TROUGAO_H_
#define _PRAVOUGLI_TROUGAO_H_

double izracunajHipotenuzu(double k1, double k2);
double izracunajObim(double k1, double k2);
double izracunajPovrsinu(double k1, double k2);

#endif  // _PRAVOUGLI_TROUGAO_H_
