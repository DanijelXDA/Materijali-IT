#include <stdio.h>

#include "pravougliTrougao.h"

double unesiDuzinuKatete()
{
	double a = 0.0;

	do
		scanf("%lf", &a);
	while (a <= 0);

	return a;
}

int main()
{
    double a, b;

	printf("Unesite duzinu prve katete pravouglog trougla (realan broj veci od 0): ");
	a = unesiDuzinuKatete();

	printf("Unesite duzinu druge katete pravouglog trougla (realan broj veci od 0): ");
	b = unesiDuzinuKatete();

	printf("Duzina hipotenuze iznosi %.2f.\n", izracunajHipotenuzu(a, b));

	printf("Obim trougla iznosi %.2f.\n", izracunajObim(a, b));
	printf("Povrsina trougla iznosi %.2f.\n", izracunajPovrsinu(a, b));

	return 0;
}
