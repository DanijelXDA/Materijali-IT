#include <math.h>

#include "koren.h"

double izracunajKoren(double broj, double koren)
{
	return pow(broj, 1 / koren);
}
