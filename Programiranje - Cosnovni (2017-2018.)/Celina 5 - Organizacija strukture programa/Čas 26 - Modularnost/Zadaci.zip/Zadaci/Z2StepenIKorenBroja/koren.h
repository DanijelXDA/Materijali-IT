#ifndef _KOREN_H_
#define _KOREN_H_

double izracunajKoren(double broj, double koren);

#endif  // _KOREN_H_
