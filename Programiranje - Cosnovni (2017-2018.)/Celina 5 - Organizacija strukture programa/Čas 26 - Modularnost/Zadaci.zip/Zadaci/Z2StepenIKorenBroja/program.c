#include <stdio.h>

#include "stepen.h"
#include "koren.h"

int main()
{
	int broj, stepen, koren;
	char izbor;

	printf("Program omogucava racunanje stepena i korena nekog broja.\n\n");

	printf("Unesite ceo broj: ");
	scanf("%d", &broj);

	printf("\nOpcije:\n");
	printf("\ts - za racunanje stepena\n");
	printf("\tk - za racunanje korena\n");
	printf("Vas izbor: ");
	scanf("\n%c", &izbor);

	switch(izbor)
	{
		case 's':
			printf("\nUnesite stepen: ");
			scanf("%d", &stepen);
			printf("\n%d. stepen broja %d je %.2f.\n", stepen, broj, izracunajStepen(broj, stepen));
			break;

		case 'k':
			printf("\nUnesite koren: ");
			scanf("%d", &koren);
			printf("\n%d. koren broja %d je %.2f.\n", koren, broj, izracunajKoren(broj, koren));
			break;

		default:
			printf("\nNije uneta ispravna operacija!\n");
			break;
	}

	return 0;
}
