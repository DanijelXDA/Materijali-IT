#include <math.h>

#include "stepen.h"

double izracunajStepen(double broj, double stepen)
{
	return pow(broj, stepen);
}
