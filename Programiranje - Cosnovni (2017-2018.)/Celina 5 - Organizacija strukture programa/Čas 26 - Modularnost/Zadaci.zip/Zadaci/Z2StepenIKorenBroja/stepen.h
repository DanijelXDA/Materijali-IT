#ifndef _STEPEN_H_
#define _STEPEN_H_

double izracunajStepen(double broj, double stepen);

#endif  // _STEPEN_H_
