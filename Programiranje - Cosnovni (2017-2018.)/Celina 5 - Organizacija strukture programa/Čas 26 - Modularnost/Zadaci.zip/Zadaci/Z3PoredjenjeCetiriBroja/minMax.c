#include "minMax.h"

double pronadjiMax(double a, double b)
{
	return (a >= b) ? a : b;
}

double pronadjiMin(double a, double b)
{
	return (a <= b) ? a : b;
}
