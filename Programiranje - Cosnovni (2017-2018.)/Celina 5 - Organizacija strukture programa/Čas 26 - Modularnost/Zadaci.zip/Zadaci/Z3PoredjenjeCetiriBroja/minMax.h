#ifndef _MINMAX_H_
#define _MINMAX_H_

double pronadjiMax(double a, double b);
double pronadjiMin(double a, double b);

#endif  // _MINMAX_H_
