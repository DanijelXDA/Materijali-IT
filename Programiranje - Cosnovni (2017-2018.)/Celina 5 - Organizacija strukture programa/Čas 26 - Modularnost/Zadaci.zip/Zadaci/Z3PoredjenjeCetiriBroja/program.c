#include <stdio.h>

#include "minMax.h"

int main()
{
	char odgovor;
    double br1, br2, br3, br4;

	do
	{
		printf("Unesite prvi broj: ");
		scanf("%lf", &br1);

		printf("Unesite drugi broj: ");
		scanf("%lf", &br2);

		printf("Unesite treci broj: ");
		scanf("%lf", &br3);

		printf("Unesite cetvrti broj: ");
		scanf("%lf", &br4);

		printf("Najveci od cetiri uneta broja je %.2f.\n", pronadjiMax(pronadjiMax(br1, br2), pronadjiMax(br3, br4)));
		printf("Najmanji od cetiri uneta broja je %.2f.\n", pronadjiMin(pronadjiMin(br1, br2), pronadjiMin(br3, br4)));

		printf("\nDa li zelite da izvrsite novi proracun [d/n]? ");
		do
			scanf("\n%c", &odgovor);
		while (odgovor != 'n' && odgovor != 'd');
	}
	while (odgovor != 'n');

	return 0;
}
