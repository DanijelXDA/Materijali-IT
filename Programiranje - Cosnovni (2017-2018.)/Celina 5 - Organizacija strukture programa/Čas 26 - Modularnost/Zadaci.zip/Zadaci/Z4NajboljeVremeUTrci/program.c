#include <stdio.h>
#include <stdlib.h>

#include "niz.h"

int main()
{
    IntegerNiz takmicari;
    ui brojTakmicara, index;

    printf("Unesite broj takmicara [1-%d]: ", MAX_DUZINA);
    brojTakmicara = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite rezultate svakog takmicara (u milisekundama):\n");
    unesiElementeNiza(takmicari, brojTakmicara);

    index = pronadjiNajmanjiElementNiza(takmicari, brojTakmicara);

    printf("\nNajbolje vreme je trcao %d. takmicar i ono iznosi %d milisekundi.\n", index + 1, takmicari[index]);

    return 0;
}
