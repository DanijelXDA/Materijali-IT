#include <stdio.h>
#include <stdlib.h>

#include "niz.h"

int main()
{
    IntegerNiz niz;
    ui brojElem;
    int operacija;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    brojElem = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite rezultate svakog takmicara:\n");
    unesiElementeNiza(niz, brojElem);

    do
    {
        printf("\nOdaberi operaciju:\n");
        printf("1 - izracunavanje sume\n");
        printf("2 - aritmeticka sredina niza\n");
        printf("0 - kraj programa\n");
        scanf("%d", &operacija);

        switch(operacija)
        {
            case 1 :
                printf("Suma elemenata = %d\n", saberiElementeNiza(niz, brojElem));
                break;

            case 2 :
                printf("Aritmeticka sredina elemenata = %.2f\n", racunajAritmetickuSredinuNiza(niz, brojElem));
                break;

            case 0 :
                printf("Kraj programa.\n");
                break;

            default:
                printf("Nije uneta ispravna operacija!\n");
                break;
        }
    }
    while(operacija);

    return 0;
}
