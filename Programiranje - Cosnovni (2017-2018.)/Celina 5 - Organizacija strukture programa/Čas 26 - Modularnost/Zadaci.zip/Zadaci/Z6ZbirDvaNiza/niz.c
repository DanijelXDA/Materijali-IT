#include <stdio.h>

#include "niz.h"

ui unesiBrojElemenataNiza(ui maxBrElem)
{
    ui brElem = 0;

    do
        scanf("%u", &brElem);
    while(brElem < 1 || brElem > maxBrElem);

    return brElem;
}

void unesiElementeNiza(IntegerNiz niz, ui brElem)
{
    ui i;

    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%u] = ", i);
        scanf("%d", &niz[i]);
    }
}

void ispisiElementeNiza(IntegerNiz niz, ui brElem)
{
    ui i;

    for(i = 0; i < brElem; ++i)
        printf("\tniz[%u] = %d\n", i + 1, niz[i]);
}

ui prebrojManjeOd(IntegerNiz niz, ui brElem, ui n)
{
    ui i, br = 0;

    for(i = 0; i < brElem; ++i)
        if(niz[i] < niz[n])
            ++br;

    return br;
}

ui pronadjiNajmanjiElementNiza(IntegerNiz niz, ui brElem)
{
    ui i, minInd = 0;

    for(i = 1; i < brElem; ++i)
        if(niz[i] < niz[minInd])
            minInd = i;

    return minInd;
}

ui pronadjiNajveciElementNiza(IntegerNiz niz, ui brElem)
{
    ui i, maxInd = 0;

    for(i = 1; i < brElem; ++i)
        if(niz[i] > niz[maxInd])
            maxInd = i;

    return maxInd;
}

double racunajZbirElemenataNiza(IntegerNiz niz, ui brElem)
{
    double suma = 0.0;
    ui i;

    for(i = 0; i < brElem; ++i)
        suma += niz[i];

    return suma;
}


double racunajAritmetickuSredinuNiza(IntegerNiz niz, ui brElem)
{
    return racunajZbirElemenataNiza(niz, brElem) / brElem;
}

int racunajSkalarniProizvodNiza(IntegerNiz v1, IntegerNiz v2, ui duzina)
{
    int skalarniProizvod = 0;
    ui i;

    for(i = 0; i < duzina; ++i)
        skalarniProizvod += v1[i] * v2[i];

    return skalarniProizvod;
}

ui prebrojZadatElementNiza(IntegerNiz niz, ui brElem, int broj)
{
    ui i, k;

    k = 0;
    for(i = 0; i < brElem; i++)
        if(niz[i] == broj)
            k++;

    return k;
}

void izbaciZadatElementNiza(IntegerNiz niz, ui *brElem, int broj)
{
    ui i, k = 0;

    for(i = 0; i < *brElem ; i++)
        if(niz[i] != broj)
        {
            niz[k] = niz[i];
            ++k;
        }

    *brElem = k;

    return;
}

void prebaciNegativneElementeNaKraj(IntegerNiz niz, ui brElem)
{
    int pom;
    ui i, j;

    i = 0;
    j = brElem - 1;
    while(i < j)
        if(niz[i] > 0)
            i++;
        else
        {
            if(niz[j] > 0)
            {
                pom = niz[i];
                niz[i] = niz[j];
                niz[j] = pom;
                j--;
            }
        }
}

void pomeriCiklicnoUDesnoZaJedan(IntegerNiz niz, ui brElem)
{
    ui i, k = 0;
    int poslednji;

    poslednji = niz[brElem - 1];

    for(i = brElem - 1; i > 0 ; --i)
        niz[i] = niz[i - 1];

    niz[0] = poslednji;
}

void pomeriCiklicnoULevoZaJedan(IntegerNiz niz, ui brElem)
{
    ui i, k = 0;
    int prvi;

    prvi = niz[0];

    for(i = 0 ; i < brElem - 1  ; ++i)
        niz[i] = niz[i + 1];

    niz[brElem - 1] = prvi;
}

int saberiElementeNiza(IntegerNiz niz, ui brElem)
{
    int suma = 0;
    ui i;

    for(i = 0; i < brElem; ++i)
        suma += niz[i];

    return suma;
}

void unesiElementeRealnogNiza(RealanNiz niz, ui brElem)
{
    ui i;

    for(i = 0; i < brElem; ++i)
    {
        printf("\tniz[%u] = ", i);
        scanf("%f", &niz[i]);
    }
}

void ispisiElementeRealnogNiza(RealanNiz niz, ui brElem)
{
    ui i;

    for(i = 0; i < brElem; ++i)
        printf("\tniz[%u] = %.2f\n", i + 1, niz[i]);
}

void formirajNizOdDvaNiza(RealanNiz ulaz1, RealanNiz ulaz2, RealanNiz izlaz, unsigned int brElem)
{
    ui i;

    for(i = 0; i < brElem; ++i)
        izlaz[i] = ulaz1[i] + ulaz2[i];
}
