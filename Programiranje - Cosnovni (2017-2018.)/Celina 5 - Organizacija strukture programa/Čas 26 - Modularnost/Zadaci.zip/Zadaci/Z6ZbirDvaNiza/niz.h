#ifndef NIZ_H_INCLUDED
#define NIZ_H_INCLUDED

#define MAX_DUZINA 20

typedef unsigned int ui;
typedef int IntegerNiz[MAX_DUZINA];
typedef float RealanNiz[MAX_DUZINA];

ui unesiBrojElemenataNiza(ui maxBrElem);
void unesiElementeNiza(IntegerNiz niz, ui brElem);
void ispisiElementeNiza(IntegerNiz niz, ui brElem);
ui prebrojManjeOd(IntegerNiz niz, ui brElem, ui n);
ui pronadjiNajmanjiElementNiza(IntegerNiz niz, ui brElem);
ui pronadjiNajveciElementNiza(IntegerNiz niz, ui brElem);
double racunajZbirElemenataNiza(IntegerNiz niz, ui brElem);
double racunajAritmetickuSredinuNiza(IntegerNiz niz, ui brElem);
int racunajSkalarniProizvodNiza(IntegerNiz v1, IntegerNiz v2, ui duzina);
ui prebrojZadatElementNiza(IntegerNiz niz, ui brElem, int broj);
void izbaciZadatElementNiza(IntegerNiz niz, ui *brElem, int broj);
void prebaciNegativneElementeNaKraj(IntegerNiz niz, ui brElem);
void pomeriCiklicnoUDesnoZaJedan(IntegerNiz niz, ui brElem);
void pomeriCiklicnoULevoZaJedan(IntegerNiz niz, ui brElem);
int saberiElementeNiza(IntegerNiz niz, ui brElem);

void unesiElementeRealnogNiza(RealanNiz niz, ui brElem);
void ispisiElementeRealnogNiza(RealanNiz niz, ui brElem);
void formirajNizOdDvaNiza(RealanNiz ulaz1, RealanNiz ulaz2, RealanNiz izlaz, ui brElem);


#endif // NIZ_H_INCLUDED
