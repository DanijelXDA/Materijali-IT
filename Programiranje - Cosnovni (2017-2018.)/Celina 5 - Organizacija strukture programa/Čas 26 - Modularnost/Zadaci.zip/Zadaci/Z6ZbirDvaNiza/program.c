#include <stdio.h>
#include <stdlib.h>

#include "niz.h"

int main()
{
    RealanNiz v1, v2, v3;
    ui duzina;

    printf("Unesite duzinu niza [1-%d]: ", MAX_DUZINA);
    duzina = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite elemente prvog niza:\n");
    unesiElementeRealnogNiza(v1, duzina);

    printf("\nUnesite elemente drugog niza:\n");
    unesiElementeRealnogNiza(v2, duzina);

    printf("\nNovi niz:\n");
    formirajNizOdDvaNiza(v1, v2, v3, duzina);
    ispisiElementeRealnogNiza(v3, duzina);

    return 0;
}
