#include <stdio.h>
#include <stdlib.h>

#include "niz.h"

int main()
{
    IntegerNiz niz;
    ui brojElem, brojRotiranja, i;

    printf("Unesite broj elemenata niza [1-%d]: ", MAX_DUZINA);
    brojElem = unesiBrojElemenataNiza(MAX_DUZINA);

    printf("\nUnesite elemente niza:\n");
    unesiElementeNiza(niz, brojElem);

    printf("\nUnesite za koliko mesta hocete da se cirkularno rotira niz u levo: ");
    brojRotiranja = unesiBrojElemenataNiza(MAX_DUZINA);

    for(i = 0; i < brojRotiranja; ++i)
        pomeriCiklicnoULevoZaJedan(niz, brojElem);

    printf("\nRotiran niz:\n");
    ispisiElementeNiza(niz, brojElem);

    return 0;
}
