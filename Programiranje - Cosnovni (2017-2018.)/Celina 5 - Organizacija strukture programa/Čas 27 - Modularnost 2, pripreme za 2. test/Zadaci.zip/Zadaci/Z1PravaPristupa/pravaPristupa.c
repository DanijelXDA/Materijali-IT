#include "pravapristupa.h"

void inicijalizujPrava()
{
    inicijalizujSkup(read);
    inicijalizujSkup(write);
}

void ispisiSvaReadPrava()
{
    printf("Read prava ");
    ispisiElementeSkupa(read);
}

void ispisiSvaWritePrava()
{
    printf("Write prava ");
    ispisiElementeSkupa(write);
}

ui imaLiElementReadPravo(ui el)
{
    return pripadaLiElementSkupu(read, el);
}

ui imaLiElementWritePravo(ui el)
{
    return pripadaLiElementSkupu(write, el);
}

ui promeniReadPravoElementa(ui el)
{
    ui rez = 0;

    if(ADMIN)
    {
        rez = 1;
        promeniPripadnostElementaSkupu(read, el);

        if(!read[el] && write[el])  // ako izgubi read pravo, automatski gubi i write pravo
            izbaciElementIzSkupa(write, el);
    }

    return rez;
}

ui promeniWritePravoElementa(ui el)
{
    ui rez = 0;

    if(ADMIN)
    {
        rez = 1;
        promeniPripadnostElementaSkupu(write, el);

        if(write[el] && !read[el])  // ako dobije write pravo, automatski dobija i read pravo ako ga nije imao (ako izgubi write pravo ostaje mu read pravo)
            dodajElementSkupu(read, el);
    }

    return rez;
}
