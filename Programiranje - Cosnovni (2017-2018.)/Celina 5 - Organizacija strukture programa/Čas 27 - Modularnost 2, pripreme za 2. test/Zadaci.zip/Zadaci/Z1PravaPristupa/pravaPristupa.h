#ifndef PRAVAPRISTUPA_H_INCLUDED
#define PRAVAPRISTUPA_H_INCLUDED

#include "skup.h"

#define ADMIN 1 //1 jeste admin, 0 nije admin, od toga zavisi moze li da menja prava ili ne

Skup read, write;

void inicijalizujPrava();
void ispisiSvaReadPrava();
void ispisiSvaWritePrava();
ui imaLiElementReadPravo(ui el);
ui imaLiElementWritePravo(ui el);
ui promeniReadPravoElementa(ui el);  // povratna vrednost: 1 uspesna operacija, 0 neuspesna operacija
ui promeniWritePravoElementa(ui el);  // povratna vrednost: 1 uspesna operacija, 0 neuspesna operacija

#endif // PRAVAPRISTUPA_H_INCLUDED
