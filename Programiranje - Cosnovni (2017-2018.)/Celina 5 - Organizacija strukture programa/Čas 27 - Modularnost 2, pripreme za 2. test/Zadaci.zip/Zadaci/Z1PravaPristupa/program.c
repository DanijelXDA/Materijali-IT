#include <stdio.h>
#include <stdlib.h>

#include "pravaPristupa.h"

int main()
{
    inicijalizujPrava();

    printf("*** Stanje read prava nakon inicijalizacije ***\n");
    ispisiSvaReadPrava();

    printf("\n\n*** Stanje write prava nakon inicijalizacije ***\n");
    ispisiSvaWritePrava();


    printf("\n\n*** Promena write prava elementima 6, 16 i 26 ***\n");

    if(promeniWritePravoElementa(6))
        printf("Uspesno promenjeno write pravo za element 6!\n");
    else
        printf("Neuspesno promenjeno write pravo za element 6!\n");

    if(promeniWritePravoElementa(16))
        printf("Uspesno promenjeno write pravo za element 16!\n");
    else
        printf("Neuspesno promenjeno write pravo za element 16!\n");

    if(promeniWritePravoElementa(26))
        printf("Uspesno promenjeno write pravo za element 26!\n");
    else
        printf("Neuspesno promenjeno write pravo za element 26!\n");

    printf("\n\n*** Stanje read prava nakon poslednje promene ***\n");
    ispisiSvaReadPrava();

    printf("\n\n*** Stanje write prava nakon poslednje promene ***\n");
    ispisiSvaWritePrava();


    printf("\n\n*** Ima li element 6 read pravo? ***\n");
    if(imaLiElementReadPravo(6))
        printf("Element 6 ima read pravo!\n");
    else
        printf("Element 6 nema read pravo!\n");

    printf("\n\n*** Ima li element 6 write pravo? ***\n");
    if(imaLiElementWritePravo(6))
        printf("Element 6 ima write pravo!\n");
    else
        printf("Element 6 nema write pravo!\n");


    printf("\n\n*** Promena read prava elementima 3 i 6 ***\n");

    if(promeniReadPravoElementa(3))
        printf("Uspesno promenjeno read pravo za element 3!\n");
    else
        printf("Neuspesno promenjeno read pravo za element 3!\n");

    if(promeniReadPravoElementa(6))
        printf("Uspesno promenjeno read pravo za element 6!\n");
    else
        printf("Neuspesno promenjeno read pravo za element 6!\n");

    printf("\n\n*** Stanje read prava nakon poslednje promene ***\n");
    ispisiSvaReadPrava();

    printf("\n\n*** Stanje write prava nakon poslednje promene ***\n");
    ispisiSvaWritePrava();


    printf("\n\n*** Ima li element 6 read pravo? ***\n");
    if(imaLiElementReadPravo(6))
        printf("Element 6 ima read pravo!\n");
    else
        printf("Element 6 nema read pravo!\n");

    printf("\n\n*** Ima li element 6 write pravo? ***\n");
    if(imaLiElementWritePravo(6))
        printf("Element 6 ima write pravo!\n");
    else
        printf("Element 6 nema write pravo!\n");


    printf("\n\n*** Ima li element 3 read pravo? ***\n");
    if(imaLiElementReadPravo(3))
        printf("Element 3 ima read pravo!\n");
    else
        printf("Element 3 nema read pravo!\n");

    printf("\n\n*** Ima li element 3 write pravo? ***\n");
    if(imaLiElementWritePravo(3))
        printf("Element 3 ima write pravo!\n");
    else
        printf("Element 3 nema write pravo!\n");



    return 0;
}
