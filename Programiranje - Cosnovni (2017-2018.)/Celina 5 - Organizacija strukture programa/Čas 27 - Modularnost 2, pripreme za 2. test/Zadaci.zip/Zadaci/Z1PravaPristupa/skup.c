#include "skup.h"

void inicijalizujSkup(Skup s)
{
    ui i;

    for(i = 0; i < MAX_DUZINA; ++i)
        s[i] = 0;
}

void ispuniSkup(Skup s)
{
    ui i;

    for(i = 0; i < MAX_DUZINA; ++i)
        s[i] = 1;
}

void ispisiElementeSkupa(Skup s)
{
    ui i;

    printf("( ");
    for(i = 0; i < MAX_DUZINA; ++i)
        if(s[i])
            printf("%u ", i);
    printf(")\n");
}

ui pripadaLiElementSkupu(Skup s, ui el)
{
    return s[el];
}

void dodajElementSkupu(Skup s, ui el)
{
    s[el] = 1;
}

void izbaciElementIzSkupa(Skup s, ui el)
{
    s[el] = 0;
}

void promeniPripadnostElementaSkupu(Skup s, ui el)
{
    s[el] = !s[el];
}
