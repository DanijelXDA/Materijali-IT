#ifndef SKUP_H_INCLUDED
#define SKUP_H_INCLUDED

#define MAX_DUZINA 50

typedef unsigned int ui;
typedef ui Skup[MAX_DUZINA];

void inicijalizujSkup(Skup s);
void ispuniSkup(Skup s);
void ispisiElementeSkupa(Skup s);
ui pripadaLiElementSkupu(Skup s, ui el);
void dodajElementSkupu(Skup s, ui el);
void izbaciElementIzSkupa(Skup s, ui el);
void promeniPripadnostElementaSkupu(Skup s, ui el);

#endif // SKUP_H_INCLUDED
